#include "re3_actor.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
static int open_world(void *ctx,float x,float z,float r){(void)ctx;(void)r;return x<=2.5f && x>=-2.5f && z<=5.0f && z>=-5.0f;}
static float floor0(void *ctx,float x,float z){(void)ctx;(void)x;(void)z;return 0;}
int main(void){
 re3_actor_def defs[]={{1,RE3_ROLE_PLAYER,.3f,1.7f,1,2,2,1,1},{2,RE3_ROLE_MERCENARY,.3f,1.7f,1,2,2,2,2},{3,RE3_ROLE_NPC,.3f,1.7f,1,2,2,3,3},{4,RE3_ROLE_ENEMY,.5f,2,1,2,2,4,4},{5,RE3_ROLE_BOSS,.8f,3,1,2,2,5,5}};
 re3_world w={open_world,floor0,0};re3_stair stair={0,0,0,2,0,1,.7f,1};
 float h,t;assert(re3_stair_sample(&stair,0,1,&h,&t)&&fabsf(h-.5f)<.0001f);
 assert(!re3_stair_sample(&stair,2,1,&h,&t));
 for(int i=0;i<5;i++){
  re3_actor a={0,0,0,0,RE3_IDLE,defs[i].id};
  re3_actor_step(&a,&defs[i],(re3_input){1,0,0},&w,&stair,1,.1f);
  assert(a.z>.09f&&a.motion==RE3_STAIR_UP&&a.y>0);
  a.heading=3.14159265358979323846f;
  re3_actor_step(&a,&defs[i],(re3_input){1,0,0},&w,&stair,1,.1f);
  assert(a.motion==RE3_STAIR_DOWN&&fabsf(a.y)<.0001f);
  a.motion=RE3_SCRIPTED;float old=a.z;
  re3_actor_step(&a,&defs[i],(re3_input){1,0,0},&w,&stair,1,.1f);assert(a.z==old);
 }
 re3_actor a={2.49f,0,0,1.5707963f,RE3_IDLE,1};
 re3_actor_step(&a,&defs[0],(re3_input){1,0,1},&w,0,0,.1f);assert(a.x<=2.5f);
 puts("PASS: stair interpolation, stair exclusion, five actor roles, ascent/descent, scripted lock, wall collision");
}
