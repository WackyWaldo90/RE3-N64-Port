#include "re3_actor.h"
#include <math.h>
static float clamp(float x,float lo,float hi){return x<lo?lo:(x>hi?hi:x);}
int re3_stair_sample(const re3_stair *s,float x,float z,float *height,float *progress){
    float dx=s->x1-s->x0,dz=s->z1-s->z0,len2=dx*dx+dz*dz;
    if(len2<0.000001f || s->half_width<0) return 0;
    float t=((x-s->x0)*dx+(z-s->z0)*dz)/len2;
    float side=fabsf((x-s->x0)*dz-(z-s->z0)*dx)/sqrtf(len2);
    if(t<0 || t>1 || side>s->half_width) return 0;
    if(height)*height=s->y0+(s->y1-s->y0)*t;
    if(progress)*progress=t;
    return 1;
}
void re3_actor_step(re3_actor *a,const re3_actor_def *d,re3_input in,const re3_world *w,const re3_stair *stairs,unsigned count,float dt){
    if(!a||!d||!w||!w->can_occupy||!w->floor_height||dt<=0||dt>0.25f)return;
    if(a->motion==RE3_SCRIPTED||a->motion==RE3_DEAD)return;
    a->heading+=clamp(in.turn,-1,1)*d->turn_speed*dt;
    float speed=(in.run?d->run_speed:d->walk_speed)*clamp(in.throttle,-1,1);
    float nx=a->x+sinf(a->heading)*speed*dt;
    float nz=a->z+cosf(a->heading)*speed*dt;
    if(w->can_occupy(w->ctx,nx,nz,d->radius)){a->x=nx;a->z=nz;}
    else {if(w->can_occupy(w->ctx,nx,a->z,d->radius))a->x=nx;
          if(w->can_occupy(w->ctx,a->x,nz,d->radius))a->z=nz;}
    float floor=w->floor_height(w->ctx,a->x,a->z);
    int on_stair=0;float h=0,t=0;
    for(unsigned i=0;i<count;i++)if(re3_stair_sample(&stairs[i],a->x,a->z,&h,&t)){floor=h;on_stair=1;break;}
    float dy=floor-a->y;
    a->y=floor;
    if(on_stair && fabsf(dy)>0.0001f)a->motion=dy>0?RE3_STAIR_UP:RE3_STAIR_DOWN;
    else if(fabsf(in.throttle)>0.01f)a->motion=in.run?RE3_RUN:RE3_WALK;
    else a->motion=fabsf(in.turn)>0.01f?RE3_TURN:RE3_IDLE;
}
