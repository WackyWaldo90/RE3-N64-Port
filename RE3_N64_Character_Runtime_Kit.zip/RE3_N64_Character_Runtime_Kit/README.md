# RE3 N64 — multi-character movement and stair prototype

Portable C99 reference module for the future **native N64** character runtime. No ROM, copyrighted character assets, or executable game build included.

## Current functionality
- Character definitions support player, Mercenaries, NPC, enemy, and boss roles with independent rig, animation bank, movement, and collision settings.
- Tank-style forward/backward movement and turning; collision via callback with axis-separated sliding fallback.
- Stair corridor detection with continuous linear height interpolation and up/down animation states.
- Scripted and dead state movement locks.
- Native GCC tests for all five roles.

## Important limits
- Stair corridor is an **engineering hypothesis**, not a recovered RE3/RE2 staircase implementation. Original game stairs may be script-controlled, discrete steps, or camera/room transitions.
- This does not parse real RDT/SCA/SCD/PLD/EMD data. The callback is where verified room collision must connect.
- No skeleton animation interpolation, graphics rendering, enemy AI, Mercenaries mode, or N64 emulator validation is claimed.
- Movement parameters and IDs in tests are synthetic, not measured game values.
- Frame step must be fixed or bounded (dt <= 0.25 seconds). Real engine should use fixed timestep and deterministic coordinate conversion.

## Test
`make test`

## N64 integration path
1. Parse actual RE3 character assets, preserve animation ID, rig and provenance.
2. Parse SCA/FLR room geometry and SCD transition scripts, verify source offsets against multiple readers.
3. Calibrate movement units, character dimensions, stair triggers and animation frames against original game behaviour.
4. Replace math library calls with fixed-point/fast-math as appropriate for N64; compile module into libdragon ROM.
5. Use native N64 graphics + controller + room loader, then verify in Ares or Mupen64Plus.

## Suggested repository destination
`engine/character/` for source/header and `tests/character/` for tests. Merge Makefile targets rather than replacing an existing project Makefile.
