#ifndef RE3_ACTOR_H
#define RE3_ACTOR_H
#include <stdint.h>
/* Engine units are arbitrary until calibrated against original game data. */
typedef enum { RE3_ROLE_PLAYER, RE3_ROLE_MERCENARY, RE3_ROLE_NPC, RE3_ROLE_ENEMY, RE3_ROLE_BOSS } re3_role;
typedef enum { RE3_IDLE, RE3_WALK, RE3_RUN, RE3_TURN, RE3_STAIR_UP, RE3_STAIR_DOWN, RE3_SCRIPTED, RE3_ATTACK, RE3_HURT, RE3_DEAD } re3_motion;
typedef struct { uint16_t id; re3_role role; float radius, height, walk_speed, run_speed, turn_speed; uint16_t rig_id, animation_bank; } re3_actor_def;
typedef struct { float x,z,y,heading; re3_motion motion; uint16_t actor_id; } re3_actor;
typedef struct { float x0,z0,x1,z1,y0,y1,half_width; uint16_t room_id; } re3_stair;
typedef struct { float min_x,min_z,max_x,max_z; } re3_wall;
typedef struct { float throttle, turn; int run; } re3_input;
/* The callbacks implement game-specific SCA/FLR collision and SCD scripting. */
typedef struct { int (*can_occupy)(void *ctx,float x,float z,float radius); float (*floor_height)(void *ctx,float x,float z); void *ctx; } re3_world;
int re3_stair_sample(const re3_stair *stair,float x,float z,float *height,float *progress);
void re3_actor_step(re3_actor *actor,const re3_actor_def *def,re3_input input,const re3_world *world,const re3_stair *stairs,unsigned stair_count,float dt);
#endif
