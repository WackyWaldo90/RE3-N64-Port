#!/usr/bin/env python3
"""Opt-in engineering diagnosis from a SANITIZED report; never submits ROM bytes."""
import json, os, pathlib, urllib.request

report = pathlib.Path(os.environ['REPORT_PATH']).read_text(encoding='utf-8')
model = os.environ.get('OPENAI_MODEL') or 'gpt-4.1-mini'
request_data = {
    'model': model,
    'instructions': ('You are a cautious N64 reverse-engineering reviewer. Propose likely root causes, '
                     'ranked experiments, and validation steps. Mark hypotheses clearly. '
                     'Never claim to have run tools. Do not request proprietary ROM bytes.'),
    'input': 'Analyze this sanitized engineering failure report:\n\n' + report,
    'max_output_tokens': 1800,
}
request = urllib.request.Request(
    'https://api.openai.com/v1/responses',
    data=json.dumps(request_data).encode(),
    headers={'Authorization': 'Bearer ' + os.environ['OPENAI_API_KEY'],
             'Content-Type': 'application/json'},
    method='POST',
)
with urllib.request.urlopen(request, timeout=90) as response:
    data = json.load(response)
text = '\n'.join(item.get('text','') for msg in data.get('output', [])
                 for item in msg.get('content', []) if item.get('type') == 'output_text')
if not text.strip():
    raise SystemExit('No diagnosis text returned; inspect API response metadata locally')
out = pathlib.Path('reports/openai-diagnosis.md')
out.parent.mkdir(exist_ok=True)
out.write_text('# Optional OpenAI engineering diagnosis\n\n' + text + '\n', encoding='utf-8')
print('Diagnosis written to', out)
