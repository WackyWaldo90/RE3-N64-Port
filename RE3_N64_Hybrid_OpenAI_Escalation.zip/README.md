# RE3 N64: ChatGPT + GitHub Actions + optional OpenAI API

- **ChatGPT GitHub connector**: interactive file reading and permitted edits, subject to GitHub integration permissions.
- **GitHub Actions**: deterministic builds, tests, emulator tooling and log collection.
- **OpenAI API escalation**: optional **manual** workflow for sanitized failure reports, never automatic on every failure.

## Install
1. Copy `.github/workflows/openai-escalation.yml` and `scripts/openai_escalation.py` into the repository, retaining paths.
2. Create a separate OpenAI API key at platform.openai.com, set spending limits, and store it as a GitHub Actions repository secret named `OPENAI_API_KEY`. Never commit the key.
3. Optionally set GitHub Actions repository variable `OPENAI_ESCALATION_MODEL` to a model supported by your API account. The script defaults to `gpt-4.1-mini`; update if unavailable.
4. Write a sanitized, text-only report such as `reports/build-failure.txt`. Remove credentials, private file paths, proprietary ROM contents and personal data before committing.
5. In GitHub Actions, select **Optional OpenAI Engineering Escalation**, choose **Run workflow**, and enter `reports/build-failure.txt`.
6. Download the `engineering-diagnosis` artifact. Review suggestions here and verify them by running actual tests.

## Guardrails
- Manual trigger only; no autonomous commits or pull requests.
- Read-only GitHub token; API key stored as secret.
- The API is a separate paid service, independent of ChatGPT/Codex usage.
- Reports must be <=64 KiB. This is NOT an executable ROM analysis engine.
- The GitHub connector may still require authorization for write operations.
