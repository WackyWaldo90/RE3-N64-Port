# Collision comparison and adaptation

The earlier static audit examined 125 PS1 RE2 Leon-side room files (2,494 records) and a PAL RE2 N64 ROM. Neither full collision sections nor record arrays matched directly in little or big endian. This does not prove collision was removed; data can be packed, reorganized or translated. Claire-side rooms were not supplied in that disc audit.

RE2 record layout is x/z signed16, width/depth unsigned16, ID unsigned16, Type unsigned16, Floor unsigned32. Earlier labels called ID “type” and Type “floor”; this build corrects that interpretation. Shape is the low four ID bits rather than the earlier three-bit assumption. C5C5C5C5 is not a reliable section identifier.

RE3 R101 records use two coordinate endpoints followed by ID, Type, Floor and another unsigned16 field. Endpoints and RE2 dimensions must not be treated interchangeably. The converter retains all raw records. This prototype supports boxes and explicitly skips other shapes. RE2 field meanings are evidence to investigate RE3 flags, not proof every bit has the same meaning.

The porting PDF suggests offline room conversion, root translation, platform API replacement and explicit endian handling. It does not provide Jill collision dimensions or a retail N64 solver. Here, preprocessing produces big-endian textures/poses and fixed-width room metadata; runtime performs projection, movement and provisional collision in native N64 code.

Primary format references consulted (no engine source copied):
- https://github.com/MeganGrass/bio-lib (Bio2/SCA, Bio3/SCA, EDD, EMR, MD2 and TIM)
- https://github.com/MeganGrass/bioclone-remake
- https://github.com/pmandin/reevengi (older field interpretations; use cautiously)

Next validation requires PS1 RE3 gameplay and room data comparison, particularly floor transitions, diagonal/capsule shapes, masks, animation roots and doorway boundaries. The old PS1-versus-N64 static audit is included for provenance, not as a recovered N64 implementation.
