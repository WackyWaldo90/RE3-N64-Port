/* Native N64 runtime, independently implemented using libdragon. */
#include "engine.h"
#include <stdio.h>
void engine_fail(const char *message)
{
    console_init();
    console_set_render_mode(RENDER_MANUAL);
    printf("RE3 engine error\n%s\n", message);
    console_render();
    for (;;) {}
}
uint32_t asset_address(const char *path, int expected_size)
{
    uint32_t address = dfs_rom_addr(path);
    if (!address || dfs_rom_size(path) != expected_size) engine_fail(path);
    return address;
}
int main(void)
{
    display_init(RESOLUTION_320x240, DEPTH_16_BPP, 2, GAMMA_NONE, FILTERS_RESAMPLE);
    if (dfs_init(DFS_DEFAULT_LOCATION) != DFS_ESUCCESS) engine_fail("ROM filesystem");
    joypad_init();
    boot_play();
    room_run();
    return 0;
}
