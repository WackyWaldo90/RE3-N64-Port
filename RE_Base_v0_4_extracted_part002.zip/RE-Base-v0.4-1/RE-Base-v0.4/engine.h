#ifndef RE3_ENGINE_H
#define RE3_ENGINE_H
#include <libdragon.h>
#include <stdint.h>
#define ENGINE_WIDTH 320
#define ENGINE_HEIGHT 240
#define ENGINE_FRAME_BYTES (ENGINE_WIDTH * ENGINE_HEIGHT * 2)
uint32_t asset_address(const char *path, int expected_size);
void engine_fail(const char *message);
void boot_play(void);
void room_run(void);
#endif
