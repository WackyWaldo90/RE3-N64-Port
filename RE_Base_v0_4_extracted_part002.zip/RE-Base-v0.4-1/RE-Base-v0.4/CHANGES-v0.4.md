# v0.4 appearance and isolated stair prototype

Jill display scale: 0.65 on all axes around existing foot origin. Palette RGB intensity: 65%, RGBA16 alpha preserved. Collision radius remains 400; mesh scale does not redefine gameplay collision. These are provisional presentation settings, not recovered Claire N64 measurements.

C-Down enters a separate stair diagnostic in camera 0; Up ascends, Down descends, B returns to ordinary warehouse movement. It uses source R101 record 6's X/Z bounds (-15094..-12584, -25805..-24185). End heights -3600/-5400, ascent along +X and radius 400 are provisional author-selected calibration. Linear support height, constrained sides and endpoint clamps are implemented. Existing box collision is bypassed ONLY in this isolated stair diagnostic. It has no connection to landing traversal, doors or other floors; no recovered stair animation is used. Walk/back clips accompany height changes.

RE2 comparison: available BioLib RE2 format research identifies a stair-special box and axis/direction fields, separate from ordinary walls. RE3 assigns different shape numbers and field meanings. No retail N64 stair routine or Claire dimensions have been recovered. Shared RPD locations do not prove that the RE3 warehouse duplicates an RE2 room. This build does not make that claim.

Validation: host checks cover ascent/descent endpoint heights, side boundaries and extreme displacement clamping. Emulator check uses ares 140, 4 MB RAM, timed C-Down/Up/Down inputs. See validation-v04 for current-build evidence. Prior v0.3 validation is not evidence for this build.

Remaining: Claire N64 model extraction and measurements; Leon N64 stair trace; source R101 stair direction, actual floor heights/flags; landing connectivity; foot/root alignment; foreground masks; authentic stair clips. This is a calibration build, not a faithful finished warehouse staircase.

The headless runner retained an obsolete telemetry address; those TRACE/TELEMETRY words are not actor evidence. HUD/frame captures are used to verify this build.

Visual result: HUD confirms elevation reaches -5400 and returns toward -3600. Jill is smaller and darker. Actor/stair alignment still does not match the photographed staircase, so the feature remains diagnostic and is NOT enabled in normal traversal.
