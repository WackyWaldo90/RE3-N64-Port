#include "../stairs.h"
#include <assert.h>
#include <math.h>
int main(void){
    StairBody b={warehouse_stair.x0,warehouse_stair.y0,-24000};
    for(int i=0;i<100;i++)stair_move(&b,70,0,&warehouse_stair);
    assert(fabsf(b.y-warehouse_stair.y1)<0.1f);
    assert(b.x==warehouse_stair.x1);
    for(int i=0;i<100;i++)stair_move(&b,-70,0,&warehouse_stair);
    assert(fabsf(b.y-warehouse_stair.y0)<0.1f);
    stair_move(&b,100000,-100000,&warehouse_stair);
    assert(b.x==warehouse_stair.x1&&b.z==warehouse_stair.z0+warehouse_stair.radius);
    return 0;
}
