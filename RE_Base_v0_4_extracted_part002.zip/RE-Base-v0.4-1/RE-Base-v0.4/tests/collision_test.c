#include "../collision.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
static RoomCollision box={0,-500,200,500,0x8001,0,0x200,0};
int main(void)
{
 CollisionBody b={-1000,0,100};int hits=collision_move(&b,1500,0,&box,1,1);assert(hits>0&&b.x<=-99.9f);
 b=(CollisionBody){-100,0,100};collision_move(&b,40,150,&box,1,1);assert(b.x<=-99.9f&&b.z>140);
 b=(CollisionBody){-300,-800,100};assert(collision_move(&b,500,700,&box,1,1)>0);
 float cx=fmaxf(0,fminf(b.x,200)),cz=fmaxf(-500,fminf(b.z,500));assert(hypotf(b.x-cx,b.z-cz)>=99.9f);
 b=(CollisionBody){-1000,0,100};RoomCollision off=box;off.id=1;collision_move(&b,1500,0,&off,1,1);assert(b.x>0);
 b=(CollisionBody){-1000,0,100};collision_move(&b,1500,0,&box,1,0);assert(b.x>0);
 b=(CollisionBody){-1000,0,100};off=box;off.id=0x8006;collision_move(&b,1500,0,&off,1,1);assert(b.x>0);
 b=(CollisionBody){-1000,0,100};assert(collision_move(&b,50000,0,&box,1,1)==-1&&b.x==-1000);
 printf("PASS: wall stop, sliding, diagonal contact, disabled flag/layer, unsupported shape and excessive-step rejection\n");
}
