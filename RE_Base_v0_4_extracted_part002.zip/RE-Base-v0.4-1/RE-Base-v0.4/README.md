# RE3 N64 Base: v0.4 ROM + Pyrite64 source integration

**The playable ROM is still v0.4. The new Pyrite64 integration is source only and has not been
compiled or emulated.** The current environment lacks the N64 SDK asset tools/compiler.
See CHANGES-PYRITE64.md and Pyrite64/README.md. Open Pyrite64/project.p64proj in Pyrite64 0.9.0
for the added project. Build evidence and host-test results are included.

# RE3 N64 v0.4 calibration build

Open RE3_N64_Engine_Collision.z64. Startup leads to the warehouse.

Jill renders at 65% of v0.3 scale and texture RGB intensity. Collision radius is unchanged. These values are provisional; Claire N64 dimensions have not been recovered.

Controls: D-pad turn/move; Z run; L/R camera; A geometry overlay; B reset; C-Up box collision toggle; Start experimental camera switching. C-Down enters an isolated stair diagnostic, Up ascends, Down descends, B exits/reset. The diagnostic clamps movement within one stair footprint and has no landing/door connection.

Read CHANGES-v0.4.md for evidence and limitations. Stair direction, height and actor alignment remain provisional. This is not recovered Leon N64 stair code. There are no enemies, room transitions, inventory or save features. Foreground occlusion is absent.

Build with make N64_INST=/absolute/path/to/libdragon. Source and converted payloads are included; original game disc is not. The prior v0.3 archive remains the baseline.
