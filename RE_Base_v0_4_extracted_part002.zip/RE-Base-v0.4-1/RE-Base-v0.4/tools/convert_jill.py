#!/usr/bin/env python3
"""Independent RE3 PLD/PLW diagnostic actor converter; BioLib/reevengi format references."""
import pathlib,struct,json,hashlib,sys
import numpy as np
source=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2])
b=(source/'PL00.PLD').read_bytes();w=(source/'PL00W00.PLW').read_bytes()
def directory(d):
 o,n=struct.unpack_from('<II',d);return struct.unpack_from('<'+str(n)+'I',d,o)
ptr=directory(b);wp=directory(w);s=ptr[1];joint,anim,bones,stride=struct.unpack_from('<4H',b,s)
rel=np.array([struct.unpack_from('<3h',b,s+8+i*6) for i in range(bones)],dtype=float);parents=[-1]*bones
for i in range(bones):
 n,p=struct.unpack_from('<HH',b,s+joint+i*4)
 for k in b[s+joint+p:s+joint+p+n]:
  if k>=bones or parents[k]!=-1:raise ValueError('Hierarchy')
  parents[k]=i
meshes=[];faces=[];md=ptr[2]+8
for i in range(bones):
 v,n,nv,t,q,nt,nq=struct.unpack_from('<5I2H',b,md+i*24)
 meshes.append(np.array([struct.unpack_from('<4h',b,md+v+j*8)[:3] for j in range(nv)],dtype=float))
 for j in range(nt):
  a=list(b[md+t+j*12:md+t+j*12+12]);faces.append((i,[a[7],a[10],a[11]],[(a[0],a[1]),(a[4],a[5]),(a[8],a[9])],a[2]|a[3]<<8,a[6]))
 for j in range(nq):
  a=list(b[md+q+j*16:md+q+j*16+16]);idx=[a[10],a[11],a[14],a[15]];uv=[(a[0],a[1]),(a[4],a[5]),(a[8],a[9]),(a[12],a[13])]
  for tri in [(0,1,2),(1,3,2)]:faces.append((i,[idx[k] for k in tri],[uv[k] for k in tri],a[2]|a[3]<<8,a[6]|a[7]<<8))
tim=ptr[4];magic,flags=struct.unpack_from('<II',b,tim);assert magic==16 and flags==9
clen,cx,cy,cw,ch=struct.unpack_from('<I4H',b,tim+8);pal=np.frombuffer(b[tim+20:tim+8+clen],dtype='<u2').astype(np.uint16)
pix=tim+8+clen;plen,ix,iy,iw,ih=struct.unpack_from('<I4H',b,pix);tw=iw*2;indices=b[pix+12:pix+plen];assert len(indices)==tw*ih
rgba=((pal&31)<<11)|(((pal>>5)&31)<<6)|(((pal>>10)&31)<<1)|(pal!=0)
(out/'filesystem/jill_indices.ci8').write_bytes(indices);(out/'filesystem/jill_palettes.rgba16').write_bytes(rgba.astype('>u2').tobytes())
# MD2 vertices are in a common bind coordinate space. Normalize each part
# to its joint before applying hierarchical animated transforms.
bind=[None]*bones
def bind_position(i):
 if bind[i] is None:bind[i]=(bind_position(parents[i])+rel[i]) if parents[i]>=0 else np.zeros(3)
 return bind[i]
for i in range(bones):meshes[i]=meshes[i]-bind_position(i)
starts=np.cumsum([0]+[len(m) for m in meshes[:-1]]);flatfaces=[]
for bone,idx,uv,clut,page in faces:
 if max(idx)>=len(meshes[bone]):raise ValueError('Vertex index')
 material=(clut>>6)-cy;tex=[(u+(page&15)*128-ix*2,v+((page>>4)&1)*256-iy) for u,v in uv]
 if not 0<=material<ch or any(not(0<=u<tw and 0<=v<ih) for u,v in tex):raise ValueError(('Texture',tex,page,material))
 flatfaces.append([int(starts[bone]+v) for v in idx]+[int(k) for uv in tex for k in uv]+[material])
def posed(d,edd,emr,clip):
 count,attr,counter=struct.unpack_from('<HHI',d,edd+clip*8);pj,pf,nb,length=struct.unpack_from('<4H',d,emr);assert nb==bones
 result=[];delays=[]
 for f in range(count):
  val=struct.unpack_from('<H',d,edd+attr+f*2)[0];pos=emr+pf+(counter+(val&255))*length;y=struct.unpack_from('<h',d,pos+6)[0]
  angle=int.from_bytes(d[pos+8:pos+length],'little');world=[None]*bones
  def matrix(i):
   if world[i] is not None:return world[i]
   ax,ay,az=[((angle>>(i*36+k*12))&4095)*np.pi/2048 for k in range(3)]
   sx,cx=np.sin(ax),np.cos(ax);sy,cy=np.sin(ay),np.cos(ay);sz,cz=np.sin(az),np.cos(az)
   rx=np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]]);ry=np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]]);rz=np.array([[cz,-sz,0],[sz,cz,0],[0,0,1]])
   m=np.eye(4);m[:3,:3]=rx@ry@rz;m[:3,3]=rel[i]
   if parents[i]>=0:m=matrix(parents[i])@m
   else:m[:3,3]=(0,y,0)
   world[i]=m;return m
  result.append(np.concatenate([mesh@matrix(i)[:3,:3].T+matrix(i)[:3,3] for i,mesh in enumerate(meshes)]));delays.append(2 if (val>>8)&2 else 1)
 return np.array(result),delays
clips=[];allframes=[];cursor=0
for label,d,ed,em,clip in [('idle',w,wp[0],wp[1],2),('walk',w,wp[0],wp[1],0),('run',w,wp[0],wp[1],1),('back',b,ptr[0],ptr[1],0)]:
 frames,delays=posed(d,ed,em,clip);clips.append(dict(name=label,offset=cursor,frames=len(frames),source_clip=clip,delays=delays));cursor+=len(frames);allframes.extend(frames)
frames=np.array(allframes);ground=float(np.max(frames[0,:,1]));frames[:,:,1]-=ground
(out/'filesystem/jill_poses.s16be').write_bytes(np.round(frames).astype('>i2').tobytes())
header=f'#define JILL_VERTICES {frames.shape[1]}\n#define JILL_TRIANGLES {len(flatfaces)}\n#define JILL_FRAMES {len(frames)}\n#define JILL_TEXTURE_W {tw}\n#define JILL_TEXTURE_H {ih}\n#define JILL_PALETTES {ch}\n'
header+='static const JillFace jill_faces[] = {\n'+',\n'.join(' {'+', '.join(str(k) for k in row[:3])+', {'+', '.join(str(k) for k in row[3:9])+'}, '+str(row[9])+'}' for row in flatfaces)+'\n};\n'
header+='static const int jill_clip_start[] = {'+', '.join(str(c['offset']) for c in clips)+'};\nstatic const int jill_clip_count[] = {'+', '.join(str(c['frames']) for c in clips)+'};\n'
header+='static const uint8_t jill_frame_delays[] = {'+', '.join(str(d) for c in clips for d in c['delays'])+'};\n';(out/'generated/jill.h').write_text(header)
report=dict(vertices=frames.shape[1],triangles=len(flatfaces),bones=bones,clips=clips,texture=[tw,ih,ch],ground_adjustment=ground,model_bounds=[frames.min(axis=(0,1)).tolist(),frames.max(axis=(0,1)).tolist()],foot_y_range=[float(frames[:,:,1].max(axis=1).min()),float(frames[:,:,1].max(axis=1).max())],source_sha256={n:hashlib.sha256((source/n).read_bytes()).hexdigest() for n in ['PL00.PLD','PL00W00.PLW']},limitations=['Prebaked diagnostic poses, not final skeletal runtime','Equipment meshes 15..20 and weapon excluded','Animation events and exact root-motion speeds not reconstructed'])
(out/'generated/jill.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='clips'},indent=2))
