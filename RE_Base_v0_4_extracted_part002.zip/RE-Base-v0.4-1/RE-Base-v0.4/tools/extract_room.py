#!/usr/bin/env python3
"""Extract the first room and Jill model from a supplied raw RE3 PS1 BIN.
This reads a single-track 2352-byte-sector BIN, not compressed disc formats.
"""
import argparse,math,pathlib,struct,json,hashlib

def extract(bin_path,destination):
    destination=pathlib.Path(destination);destination.mkdir(parents=True,exist_ok=True)
    wanted={'CD_DATA/STAGE1/R101.ARD','CD_DATA/STAGE1/R101.BSS','CD_DATA/PLD/PL00.PLD','CD_DATA/PLD/PL00W00.PLW'}
    found=[]
    with open(bin_path,'rb') as disc:
        def logical(lba,size):
            parts=[]
            for i in range(math.ceil(size/2048)):
                disc.seek((lba+i)*2352);s=disc.read(2352)
                if len(s)!=2352 or s[15] not in (1,2):raise ValueError('Invalid raw CD sector')
                start=24 if s[15]==2 else 16;parts.append(s[start:start+2048])
            return b''.join(parts)[:size]
        def walk(lba,size,prefix=''):
            data=logical(lba,size);pos=0
            while pos<len(data):
                n=data[pos]
                if not n:pos=(pos//2048+1)*2048;continue
                r=data[pos:pos+n];pos+=n
                if len(r)<34:raise ValueError('Invalid ISO directory record')
                name=r[33:33+r[32]]
                if name in (b'\0',b'\1'):continue
                name=name.decode('ascii').split(';')[0];path=prefix+name
                extent=struct.unpack_from('<I',r,2)[0];length=struct.unpack_from('<I',r,10)[0]
                if r[25]&2:walk(extent,length,path+'/')
                elif path in wanted:
                    payload=logical(extent,length);(destination/name).write_bytes(payload)
                    found.append(dict(path=path,bytes=length,sha256=hashlib.sha256(payload).hexdigest()))
        pvd=logical(16,2048)
        if pvd[1:6]!=b'CD001':raise ValueError('Not ISO9660 raw BIN')
        root=pvd[156:];walk(struct.unpack_from('<I',root,2)[0],struct.unpack_from('<I',root,10)[0])
    if len(found)!=len(wanted):raise ValueError('Expected RE3 room/model files not found')
    (destination/'extraction.json').write_text(json.dumps(found,indent=2)+'\n')
    for item in found:print(item['path'],item['bytes'])
if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('bin');a.add_argument('destination');args=a.parse_args();extract(args.bin,args.destination)
