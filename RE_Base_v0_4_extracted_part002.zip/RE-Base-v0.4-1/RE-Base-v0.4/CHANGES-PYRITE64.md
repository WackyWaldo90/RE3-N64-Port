# Pyrite64 source integration update

Status: SOURCE INTEGRATION PREPARED; N64 BUILD BLOCKED; ROM UNCHANGED.

The original RE-Base-v0.4 uses custom C/libdragon, not Pyrite64. Added Pyrite64/project.p64proj,
source lifecycle hooks, converted opening WAV, reusable v0.4 room/actor/collision/stair modules,
raw DFS payload build dependencies, and 28 background PNGs for editor asset inspection.

The actual uploaded Pyrite64 0.9.0 CLI loaded this project and generated five hook calls.
Build stopped at missing N64 SDK bin/mksprite before compiling C/C++.
Existing collision and stair host tests pass. No Pyrite-linked ROM, emulator demonstration,
GPU model conversion, improved FPS or completed staircase is claimed.

The included RE3_N64_Engine_Collision.z64 is the unchanged original v0.4 playable calibration
build. Its SHA256 is recorded in Pyrite64/validation/status.json. The original C build remains
available through the root Makefile. All existing source assets and v0.4 notes are retained.

Read Pyrite64/README.md for the integration, build instructions, limitations and required tests.
