/* Native N64 boot-to-pretitle demo. No RE2 executable code is used.
 * Asset pixels: Capcom RE3 PS1 Europe. Runtime: open-source libdragon.
 */
#include "engine.h"
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define WIDTH 320
#define HEIGHT 240
#define STILL_BYTES (WIDTH * HEIGHT * 2)
#define MOVIE_HEIGHT 160
#define MOVIE_Y 40
#define FRAME_BYTES (WIDTH * MOVIE_HEIGHT * 2)
#define FRAME_COUNT 236
#define FPS 15
#define PCM_RATE 22050
#define PCM_BYTES 1368864
#define WARNING_MS 5000
#define CAPCOM_MS 3000

static uint8_t *pcm;
static uint32_t pcm_position;

static void audio_fill(short *output, size_t samples)
{
    size_t bytes = samples * 4;
    size_t remaining = PCM_BYTES - pcm_position;
    size_t take = remaining < bytes ? remaining : bytes;
    memcpy(output, pcm + pcm_position, take);
    memset((uint8_t *)output + take, 0, bytes - take);
    pcm_position += take;
}

static void show_still(uint32_t address, uint32_t duration_ms)
{
    uint64_t start = get_ticks_ms();
    do {
        surface_t *frame = display_get();
        dma_read(frame->buffer, address, STILL_BYTES);
        display_show(frame);
    } while (get_ticks_ms() - start < duration_ms);
}

void boot_play(void)
{
    uint32_t warning = asset_address("/re3_warning.rgba16", STILL_BYTES);
    uint32_t capcom = asset_address("/re3_capcom.rgba16", STILL_BYTES);
    uint32_t movie = asset_address("/re3_opening.rgba16", FRAME_COUNT * FRAME_BYTES);
    uint32_t soundtrack = asset_address("/re3_opening.pcm16be", PCM_BYTES);

    pcm = malloc_uncached(PCM_BYTES);
    if (!pcm) engine_fail("Not enough memory for soundtrack");
    dma_read(pcm, soundtrack, PCM_BYTES);

    show_still(warning, WARNING_MS);
    show_still(capcom, CAPCOM_MS);

    /* Preload frame zero, then start audio alongside its presentation.
       Subsequent frames follow the N64 clock, with a silent audio tail. */
    surface_t *frame = display_get();
    memset(frame->buffer, 0, STILL_BYTES);
    dma_read((uint8_t *)frame->buffer + MOVIE_Y * WIDTH * 2, movie, FRAME_BYTES);
    audio_init(PCM_RATE, 4);
    pcm_position = 0;
    uint64_t started = get_ticks();
    display_show(frame);
    audio_set_buffer_callback(audio_fill);
    audio_write_silence(); /* Kick AI: the callback supplies actual PCM. */

    int displayed = 0;
    for (;;) {
        uint64_t elapsed = get_ticks() - started;
        unsigned wanted = elapsed * FPS / TICKS_PER_SECOND;
        if (wanted >= FRAME_COUNT) break;
        if ((int)wanted == displayed) continue;

        frame = display_get();
        memset(frame->buffer, 0, STILL_BYTES);
        dma_read((uint8_t *)frame->buffer + MOVIE_Y * WIDTH * 2,
                 movie + wanted * FRAME_BYTES, FRAME_BYTES);
        display_show(frame);
        displayed = wanted;
    }

    audio_set_buffer_callback(NULL);
    audio_close();
    free_uncached(pcm);
}
