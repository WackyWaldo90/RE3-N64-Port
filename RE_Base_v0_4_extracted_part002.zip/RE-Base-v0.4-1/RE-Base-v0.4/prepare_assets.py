"""Restore build assets from the supplied ROM without duplicating them in the ZIP."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'build_manifest.json').read_text())
rom=(root/'RE3_N64_Engine_Collision.z64').read_bytes()
if hashlib.sha256(rom).hexdigest()!=manifest['rom_sha256']:
 raise SystemExit('ROM hash differs from this package. Use the supplied v0.3 ROM.')
out=root/'filesystem';out.mkdir(exist_ok=True)
for asset in manifest['assets']:
 data=rom[asset['rom_offset']:asset['rom_offset']+asset['bytes']]
 if hashlib.sha256(data).hexdigest()!=asset['sha256']:raise SystemExit('Asset hash mismatch: '+asset['name'])
 (out/asset['name']).write_bytes(data)
 print('Restored',asset['name'],len(data),'bytes')
