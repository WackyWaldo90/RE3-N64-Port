/* R101 diagnostic room scene: native camera projection, cartridge streaming,
 * fixed-step input and experimental RVD switching. No gameplay is emulated.
 */
#include "engine.h"
#include "actor.h"
#include "collision.h"
#include "stairs.h"
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct { int focal; int32_t fx, fy, fz, tx, ty, tz; } RoomCamera;
typedef struct { uint16_t flags; uint8_t from, to, boundary; int16_t xy[8]; } RoomZone;

#include "generated/r101.h"
typedef struct { float x,y,z; } Vec3;
static Vec3 actor, forward, right, up;
static float heading;
volatile uint32_t re3_test_telemetry[12];
static uint32_t float_bits(float v){uint32_t bits;memcpy(&bits,&v,4);return bits;}
static int stair_test;
static int contact_hits,collision_enabled=1;
static void reset_actor(void){stair_test=0;actor=(Vec3){-11000,-3600,-22000};heading=0;}
static int camera_index, show_map, auto_camera;
static uint16_t *background;
static uint32_t backgrounds_rom;
static Vec3 sub(Vec3 a,Vec3 b){return (Vec3){a.x-b.x,a.y-b.y,a.z-b.z};}
static float dot(Vec3 a,Vec3 b){return a.x*b.x+a.y*b.y+a.z*b.z;}
static Vec3 cross(Vec3 a,Vec3 b){return (Vec3){a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
static Vec3 normal(Vec3 a){float n=sqrtf(dot(a,a));return (Vec3){a.x/n,a.y/n,a.z/n};}
static void set_camera(int index, int reset)
{
    camera_index=(index+ROOM_CAMERA_COUNT)%ROOM_CAMERA_COUNT;
    const RoomCamera *c=&room_cameras[camera_index];
    forward=normal((Vec3){c->tx-c->fx,c->ty-c->fy,c->tz-c->fz});
    right=normal(cross(forward,(Vec3){0,-1,0}));
    up=cross(right,forward);
    dma_read(background,backgrounds_rom+camera_index*ENGINE_FRAME_BYTES,ENGINE_FRAME_BYTES);
    if(reset)reset_actor();
}
int room_project_point(float x,float y,float z,float *sx,float *sy,float *depth)
{
 const RoomCamera *c=&room_cameras[camera_index];Vec3 d=sub((Vec3){x,y,z},(Vec3){c->fx,c->fy,c->fz});
 *depth=dot(d,forward);if(*depth<100)return 0;
 *sx=160+c->focal*dot(d,right)/ *depth;*sy=120-c->focal*dot(d,up)/ *depth;return 1;
}
static int project(Vec3 point,int *x,int *y)
{
    const RoomCamera *c=&room_cameras[camera_index];
    Vec3 d=sub(point,(Vec3){c->fx,c->fy,c->fz});float z=dot(d,forward);
    if(z<100)return 0;
    float sx=160+c->focal*dot(d,right)/z,sy=120-c->focal*dot(d,up)/z;
    if(sx<-320||sx>640||sy<-240||sy>480)return 0;
    *x=(int)sx;*y=(int)sy;return 1;
}
static int inside(const RoomZone *zone,float x,float z)
{
    int hit=0;
    for(int i=0,j=3;i<4;j=i++){
        float xi=zone->xy[i*2],zi=zone->xy[i*2+1],xj=zone->xy[j*2],zj=zone->xy[j*2+1];
        if(((zi>z)!=(zj>z)) && x<(xj-xi)*(z-zi)/(zj-zi)+xi)hit=!hit;
    }
    return hit;
}
static void tick(joypad_inputs_t input)
{
    float turn=(input.btn.d_right-input.btn.d_left)*0.065f+input.stick_x*0.00085f;
    float speed=(input.btn.d_up-input.btn.d_down)*70.0f+input.stick_y*0.85f;
    heading+=turn;
    if(input.btn.z)speed*=1.7f;
    /* Diagnostic walkway inside source record 6. Endpoint heights are provisional.
       Shared-world traversal, never screen-space translation or per-camera scaling. */
    if(stair_test){
        StairBody b={actor.x,actor.y,actor.z};
        stair_move(&b,sinf(heading)*speed,cosf(heading)*speed,&warehouse_stair);
        actor=(Vec3){b.x,b.y,b.z};
        jill_tick(fabsf(speed)<0.1f?0:speed<0?3:1);
        re3_test_telemetry[0]=0x45334332;re3_test_telemetry[4]=float_bits(actor.x);
        re3_test_telemetry[5]=float_bits(actor.z);re3_test_telemetry[6]=float_bits(actor.y);
        re3_test_telemetry[7]++;return;
    }
    float oldx=actor.x,oldz=actor.z;
    CollisionBody body={actor.x,actor.z,400};
    if(collision_enabled)contact_hits=collision_move(&body,sinf(heading)*speed,cosf(heading)*speed,room_collisions,ROOM_COLLISION_COUNT,1);
    else{body.x+=sinf(heading)*speed;body.z+=cosf(heading)*speed;contact_hits=0;}
    actor.x=body.x;actor.z=body.z;
    re3_test_telemetry[0]=0x45334331;re3_test_telemetry[1]=camera_index;
    re3_test_telemetry[2]=collision_enabled;re3_test_telemetry[3]=contact_hits;
    re3_test_telemetry[4]=float_bits(actor.x);re3_test_telemetry[5]=float_bits(actor.z);
    re3_test_telemetry[6]=float_bits(actor.y);re3_test_telemetry[7]++;
    if(contact_hits)re3_test_telemetry[8]++;

    float moved=fabsf(actor.x-oldx)+fabsf(actor.z-oldz);
    jill_tick(moved<0.1f?0:speed<0?3:input.btn.z?2:1);
    if(auto_camera){
        for(int i=0;i<ROOM_ZONE_COUNT;i++){
            const RoomZone *z=&room_zones[i];
            if(!z->boundary&&z->from==camera_index&&z->to!=camera_index&&inside(z,actor.x,actor.z)){
                set_camera(z->to,0);break;
            }
        }
    }
}
static int map_x(int x){return 224+(x+32000)*88/34000;}
static int map_z(int z){return 37+(z+32000)*88/34000;}
static void map_draw(surface_t *frame)
{
    uint32_t grey=graphics_make_color(100,100,100,255),yellow=graphics_make_color(255,210,0,255);
    graphics_draw_box(frame,222,35,94,94,graphics_make_color(0,0,0,255));
    for(int i=0;i<ROOM_COLLISION_COUNT;i++){
        const RoomCollision *c=&room_collisions[i];
        int x=map_x(c->x1),z=map_z(c->z1),xx=map_x(c->x2),zz=map_z(c->z2);
        graphics_draw_line(frame,x,z,xx,z,grey);graphics_draw_line(frame,xx,z,xx,zz,grey);
        graphics_draw_line(frame,xx,zz,x,zz,grey);graphics_draw_line(frame,x,zz,x,z,grey);
    }
    for(int i=0;i<ROOM_ZONE_COUNT;i++)if(room_zones[i].from==camera_index){
        const RoomZone *z=&room_zones[i];
        for(int k=0;k<4;k++)graphics_draw_line(frame,map_x(z->xy[k*2]),map_z(z->xy[k*2+1]),map_x(z->xy[((k+1)%4)*2]),map_z(z->xy[((k+1)%4)*2+1]),yellow);
    }
    int x=map_x((int)actor.x),z=map_z((int)actor.z);
    if(x>=224&&x<314&&z>=37&&z<127)graphics_draw_box(frame,x-2,z-2,5,5,graphics_make_color(0,255,255,255));
}
static void render(surface_t *frame)
{
    memcpy(frame->buffer,background,ENGINE_FRAME_BYTES);
    jill_draw(frame,actor.x,actor.y,actor.z,heading);
    uint32_t cyan=graphics_make_color(0,255,255,255),white=graphics_make_color(255,255,255,255),black=graphics_make_color(0,0,0,255);
    int x,y,xx,yy;
    if(project(actor,&x,&y)&&x>=5&&x<315&&y>=5&&y<235){
        graphics_draw_line(frame,x-5,y,x+5,y,cyan);graphics_draw_line(frame,x,y-5,x,y+5,cyan);
        if(project((Vec3){actor.x+sinf(heading)*700,actor.y,actor.z+cosf(heading)*700},&xx,&yy))graphics_draw_line(frame,x,y,xx,yy,cyan);
    }
    if(show_map)map_draw(frame);
    graphics_draw_box(frame,0,0,320,27,black);graphics_set_color(white,black);
    char line[64];snprintf(line,sizeof(line),"RE3 R101  CAM %02d/27  AUTO %s",camera_index,auto_camera?"ON":"OFF");
    graphics_draw_text(frame,4,3,line);snprintf(line,sizeof(line),"JILL  BOX TEST %s  CONTACTS %d",collision_enabled?"ON":"OFF",contact_hits);
    if(stair_test)snprintf(line,sizeof(line),"STAIR PROTOTYPE Y %d",(int)actor.y);
    graphics_draw_text(frame,4,15,line);
    graphics_draw_box(frame,0,216,320,24,black);
    graphics_draw_text(frame,4,217,"MOVE: D-PAD  Z: RUN  L/R: VIEW");
    graphics_draw_text(frame,4,229,"C-DN:STAIR B:RESET A:MAP");
}
void room_run(void)
{
    backgrounds_rom=asset_address("/r101_backgrounds.rgba16",ROOM_CAMERA_COUNT*ENGINE_FRAME_BYTES);
    background=malloc_uncached(ENGINE_FRAME_BYTES);
    if(!background)engine_fail("Room background allocation");
    set_camera(0,1);
    jill_init();
    uint64_t previous=get_ticks();double accumulated=0;
    for(;;){
        joypad_poll();joypad_inputs_t input=joypad_get_inputs(JOYPAD_PORT_1);
        joypad_buttons_t pressed=joypad_get_buttons_pressed(JOYPAD_PORT_1);
        if(pressed.r)set_camera(camera_index+1,0);
        if(pressed.l)set_camera(camera_index-1,0);
        if(pressed.a)show_map=!show_map;
        if(pressed.b)reset_actor();
        if(pressed.c_down){
            stair_test=1;auto_camera=0;show_map=0;set_camera(0,0);
            actor=(Vec3){warehouse_stair.x0,warehouse_stair.y0,(warehouse_stair.z0+warehouse_stair.z1)*0.5f};
            heading=1.570796327f;
        }
        if(pressed.c_up)collision_enabled=!collision_enabled;
        if(pressed.start)auto_camera=!auto_camera;
        uint64_t now=get_ticks();double elapsed=(double)(now-previous)/TICKS_PER_SECOND;previous=now;
        if(elapsed>0.1)elapsed=0.1;
        accumulated+=elapsed;
        while(accumulated>=1.0/30.0){tick(input);accumulated-=1.0/30.0;}
        surface_t *frame=display_get();render(frame);display_show(frame);
    }
}
