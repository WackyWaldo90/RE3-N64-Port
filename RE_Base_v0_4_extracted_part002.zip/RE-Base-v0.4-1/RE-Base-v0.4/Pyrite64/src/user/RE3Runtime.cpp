// Pyrite64 0.9.0 lifecycle integration. N64 build/runtime validation pending.
#include "script/globalScript.h"
#include "audio/audioManager.h"
#include "libdragon.h"
#include "../legacy/re3_bridge.h"
#include <cstring>

namespace {
constexpr unsigned FRAME_COUNT=236, MOVIE_FRAME_BYTES=320*160*2;
enum class Phase { Warning, Capcom, Movie, Room };
Phase phase=Phase::Warning;
surface_t composed{};
uint32_t warningRom{},capcomRom{},movieRom{};
uint64_t started{},previous{};
int loadedMovieFrame=-1;
bool roomReady=false, soundOpen=false;
wav64_t soundtrack{};
P64::Audio::Handle soundHandle{};

void enterMovie(uint64_t now)
{
    phase=Phase::Movie;started=now;loadedMovieFrame=-1;
    wav64_open(&soundtrack,"rom:/opening.wav64");
    soundOpen=true;
    soundHandle=P64::AudioManager::play2D(&soundtrack);
}
void enterRoom()
{
    soundHandle.stop();
    if(soundOpen){wav64_close(&soundtrack);soundOpen=false;}
    re3_room_init();roomReady=true;phase=Phase::Room;
}
}

namespace P64::GlobalScript::C524533505952495 {
void onScenePostLoad()
{
    // Engine owns VI, DFS, controller polling, audio mixer and presentation.
    composed=surface_alloc(FMT_RGBA16,320,240);
    if(!composed.buffer)engine_fail("Composition surface allocation");
    warningRom=asset_address("/re3_warning.rgba16",ENGINE_FRAME_BYTES);
    capcomRom=asset_address("/re3_capcom.rgba16",ENGINE_FRAME_BYTES);
    movieRom=asset_address("/re3_opening.rgba16",FRAME_COUNT*MOVIE_FRAME_BYTES);
    phase=Phase::Warning;roomReady=false;soundOpen=false;loadedMovieFrame=-1;
    started=previous=get_ticks();
}
void onSceneUpdate()
{
    uint64_t now=get_ticks();
    double elapsed=double(now-previous)/TICKS_PER_SECOND;previous=now;
    uint64_t phaseTicks=now-started;
    if(phase==Phase::Warning && phaseTicks>=5*TICKS_PER_SECOND){
        phase=Phase::Capcom;started=now;
    }else if(phase==Phase::Capcom && phaseTicks>=3*TICKS_PER_SECOND){
        enterMovie(now);
    }else if(phase==Phase::Movie && phaseTicks*15/TICKS_PER_SECOND>=FRAME_COUNT){
        enterRoom();
    }else if(phase==Phase::Room){
        // Pyrite polls controllers before this hook. Retain legacy 30 Hz logic.
        re3_room_update(elapsed,joypad_get_inputs(JOYPAD_PORT_1),
            joypad_get_buttons_pressed(JOYPAD_PORT_1));
    }
}
void onScenePreDraw()
{
    // RDP reads this reusable source asynchronously. Finish the previous read
    // before writing it again; performance must be profiled on an actual build.
    rspq_wait();
    if(phase==Phase::Warning || phase==Phase::Capcom){
        dma_read(composed.buffer,phase==Phase::Warning?warningRom:capcomRom,ENGINE_FRAME_BYTES);
    }else if(phase==Phase::Movie){
        unsigned wanted=unsigned((get_ticks()-started)*15/TICKS_PER_SECOND);
        if(wanted>=FRAME_COUNT)wanted=FRAME_COUNT-1;
        if(int(wanted)!=loadedMovieFrame){
            std::memset(composed.buffer,0,ENGINE_FRAME_BYTES);
            dma_read(static_cast<uint8_t*>(composed.buffer)+40*320*2,
                movieRom+wanted*MOVIE_FRAME_BYTES,MOVIE_FRAME_BYTES);
            loadedMovieFrame=int(wanted);
        }
    }else{re3_room_draw(&composed);}
}
void onSceneDraw2D()
{
    // Handles images larger than TMEM through the libdragon blitter.
    // Jill still uses the legacy CPU renderer; this is not a tiny3d conversion.
    rdpq_mode_push();
    rdpq_set_mode_copy(false);
    rdpq_tex_blit(&composed,0,0,nullptr);
    rdpq_mode_pop();
}
void onScenePreUnload()
{
    rspq_wait();
    soundHandle.stop();
    if(soundOpen){wav64_close(&soundtrack);soundOpen=false;}
    if(roomReady){re3_room_shutdown();roomReady=false;}
    surface_free(&composed);composed={};
}
}
