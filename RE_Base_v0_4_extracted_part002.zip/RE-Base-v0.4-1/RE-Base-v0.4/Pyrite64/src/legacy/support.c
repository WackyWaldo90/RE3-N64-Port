#include "engine.h"
#include <assert.h>
void engine_fail(const char *message)
{
    assertf(0, "RE3 integration error: %s", message);
    for (;;) {}
}
uint32_t asset_address(const char *path, int expected_size)
{
    uint32_t address=dfs_rom_addr(path);
    if(!address || dfs_rom_size(path)!=expected_size)engine_fail(path);
    return address;
}
