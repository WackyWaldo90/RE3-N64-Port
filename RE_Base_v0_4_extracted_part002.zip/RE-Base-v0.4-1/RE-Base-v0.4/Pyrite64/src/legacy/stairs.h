#ifndef STAIRS_H
#define STAIRS_H
typedef struct {float x0,x1,z0,z1,y0,y1,radius;} StairRamp;
typedef struct {float x,y,z;} StairBody;
/* R101 record 6 bounds. Heights/direction are diagnostic calibration only. */
static const StairRamp warehouse_stair={-15094,-12584,-25805,-24185,-3600,-5400,400};
void stair_move(StairBody *b,float dx,float dz,const StairRamp *r);
#endif
