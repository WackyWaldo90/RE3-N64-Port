/* Independent CPU diagnostic renderer; actual converted RE3 indexed textures
 * and animated poses. Replace with RSP/RDP backend after semantic validation. */
#include "actor.h"
#include <math.h>
#include <stdlib.h>
#include <stdint.h>
typedef struct {uint16_t a,b,c,uv[6];uint8_t palette;} JillFace;
#include "generated/jill.h"
typedef struct {float x,y,z;} ScreenPoint;
typedef struct {int face;float depth;} DrawFace;
static uint8_t *indices;
static uint16_t *palettes;
static int16_t *pose;
static uint32_t poses_rom;
static ScreenPoint screen_points[JILL_VERTICES];
static DrawFace drawing[JILL_TRIANGLES];
/* Provisional presentation calibration; not measured N64 Claire dimensions. */
#define JILL_DISPLAY_SCALE 0.65f
static int current_clip=-1,current_frame,frame_delay;
static void load_pose(void){dma_read(pose,poses_rom+(jill_clip_start[current_clip]+current_frame)*JILL_VERTICES*6,JILL_VERTICES*6);}
void jill_init(void)
{
    indices=malloc_uncached(JILL_TEXTURE_W*JILL_TEXTURE_H);
    palettes=malloc_uncached(JILL_PALETTES*256*2);
    pose=malloc_uncached(JILL_VERTICES*6);
    if(!indices||!palettes||!pose)engine_fail("Jill allocation");
    dma_read(indices,asset_address("/jill_indices.ci8",JILL_TEXTURE_W*JILL_TEXTURE_H),JILL_TEXTURE_W*JILL_TEXTURE_H);
    dma_read(palettes,asset_address("/jill_palettes.rgba16",JILL_PALETTES*256*2),JILL_PALETTES*256*2);
    /* 65 percent RGB intensity. Preserve RGBA16 alpha and original disc assets. */
    for(int i=0;i<JILL_PALETTES*256;i++) {
        uint16_t c=palettes[i];
        palettes[i]=((((c>>11)&31)*65/100)<<11)|((((c>>6)&31)*65/100)<<6)|((((c>>1)&31)*65/100)<<1)|(c&1);
    }
    poses_rom=asset_address("/jill_poses.s16be",JILL_FRAMES*JILL_VERTICES*6);
    current_clip=0;current_frame=0;frame_delay=0;load_pose();
}
void jill_tick(int clip)
{
    if(clip!=current_clip){current_clip=clip;current_frame=0;frame_delay=0;load_pose();return;}
    if(++frame_delay>=jill_frame_delays[jill_clip_start[current_clip]+current_frame]){
        frame_delay=0;current_frame=(current_frame+1)%jill_clip_count[current_clip];load_pose();
    }
}
static int compare(const void *a,const void *b)
{
    float delta=((const DrawFace*)b)->depth-((const DrawFace*)a)->depth;
    return delta>0?1:delta<0?-1:0;
}
static void triangle(surface_t *frame,const JillFace *f)
{
    ScreenPoint a=screen_points[f->a],b=screen_points[f->b],c=screen_points[f->c];
    float area=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
    if(fabsf(area)<0.3f)return;
    int x0=(int)floorf(fminf(a.x,fminf(b.x,c.x))),x1=(int)ceilf(fmaxf(a.x,fmaxf(b.x,c.x)));
    int y0=(int)floorf(fminf(a.y,fminf(b.y,c.y))),y1=(int)ceilf(fmaxf(a.y,fmaxf(b.y,c.y)));
    if(x0<0)x0=0;
    if(x1>319)x1=319;
    if(y0<27)y0=27;
    if(y1>215)y1=215;
    float inv=1.0f/area;
    for(int y=y0;y<=y1;y++){
        uint16_t *row=(uint16_t*)frame->buffer+y*ENGINE_WIDTH;
        for(int x=x0;x<=x1;x++){
            float px=x+0.5f,py=y+0.5f;
            float w1=((px-a.x)*(c.y-a.y)-(py-a.y)*(c.x-a.x))*inv;
            float w2=((b.x-a.x)*(py-a.y)-(b.y-a.y)*(px-a.x))*inv;
            float w0=1-w1-w2;
            if(w0<0||w1<0||w2<0)continue;
            int u=(int)(w0*f->uv[0]+w1*f->uv[2]+w2*f->uv[4]);
            int v=(int)(w0*f->uv[1]+w1*f->uv[3]+w2*f->uv[5]);
            if(u<0||u>=JILL_TEXTURE_W||v<0||v>=JILL_TEXTURE_H)continue;
            uint16_t color=palettes[f->palette*256+indices[v*JILL_TEXTURE_W+u]];
            if(color&1)row[x]=color;
        }
    }
}
void jill_draw(surface_t *frame,float x,float y,float z,float heading)
{
    float angle=heading-1.570796327f,s=sinf(angle),c=cosf(angle);
    for(int i=0;i<JILL_VERTICES;i++){
        float vx=pose[i*3]*JILL_DISPLAY_SCALE,vy=pose[i*3+1]*JILL_DISPLAY_SCALE,vz=pose[i*3+2]*JILL_DISPLAY_SCALE;
        if(!room_project_point(x+c*vx+s*vz,y+vy,z-s*vx+c*vz,&screen_points[i].x,&screen_points[i].y,&screen_points[i].z))screen_points[i].z=-1;
    }
    int count=0;
    for(int i=0;i<JILL_TRIANGLES;i++){
        const JillFace *f=&jill_faces[i];
        if(screen_points[f->a].z<=100||screen_points[f->b].z<=100||screen_points[f->c].z<=100)continue;
        drawing[count++]=(DrawFace){i,screen_points[f->a].z+screen_points[f->b].z+screen_points[f->c].z};
    }
    qsort(drawing,count,sizeof(DrawFace),compare);
    for(int i=0;i<count;i++)triangle(frame,&jill_faces[drawing[i].face]);
}

void jill_shutdown(void)
{
    free_uncached(indices);free_uncached(palettes);free_uncached(pose);
    indices=NULL;palettes=NULL;pose=NULL;
}
