/* Prototype circle/box solver. Raw shape IDs and fields are retained.
 * The layer mask filter is provisional RE3 high-byte mask interpretation,
 * not recovered Capcom collision logic. Unknown shapes are not boxed. */
#include "collision.h"
#include <math.h>
static float clamp(float v,float lo,float hi){return fmaxf(lo,fminf(v,hi));}
static int contact(CollisionBody *b,const RoomCollision *c)
{
    float x0=fminf(c->x1,c->x2),x1=fmaxf(c->x1,c->x2),z0=fminf(c->z1,c->z2),z1=fmaxf(c->z1,c->z2);
    float x=clamp(b->x,x0,x1),z=clamp(b->z,z0,z1),dx=b->x-x,dz=b->z-z,d2=dx*dx+dz*dz;
    if(d2>=b->radius*b->radius)return 0;
    if(d2>0.001f){float d=sqrtf(d2),push=b->radius-d+0.01f;b->x+=dx/d*push;b->z+=dz/d*push;}
    else{
        float d[4]={b->x-x0,x1-b->x,b->z-z0,z1-b->z};int face=0;
        for(int i=1;i<4;i++)if(d[i]<d[face])face=i;
        if(face==0)b->x=x0-b->radius-0.01f;
        if(face==1)b->x=x1+b->radius+0.01f;
        if(face==2)b->z=z0-b->radius-0.01f;
        if(face==3)b->z=z1+b->radius+0.01f;
    }
    return 1;
}
int collision_move(CollisionBody *b,float dx,float dz,const RoomCollision *records,int count,int layer)
{
    int hits=0,steps=(int)ceilf(sqrtf(dx*dx+dz*dz)/(b->radius*0.25f));
    if(steps<1)steps=1;
    if(steps>64)return -1; /* Reject unsupported displacement rather than tunnel. */
    float startx=b->x,startz=b->z;
    for(int k=0;k<steps;k++){
        b->x+=dx/steps;b->z+=dz/steps;
        for(int pass=0;pass<8;pass++){
            int changed=0;
            for(int i=0;i<count;i++){
                const RoomCollision *c=&records[i];
                if((c->id&15)!=1||!(c->id&0x8000)||!((c->floor_mask>>8)&(1u<<layer)))continue;
                if(contact(b,c)){hits++;changed=1;}
            }
            if(!changed)break;
            if(pass==7){b->x=startx;b->z=startz;return hits;}
        }
        startx=b->x;startz=b->z;
    }
    return hits;
}
