#ifndef COLLISION_H
#define COLLISION_H
#include <stdint.h>
typedef struct {int16_t x1,z1,x2,z2;uint16_t id,type,floor_mask,group;} RoomCollision;
typedef struct {float x,z,radius;} CollisionBody;
int collision_move(CollisionBody *body,float dx,float dz,const RoomCollision *records,int count,int layer);
#endif
