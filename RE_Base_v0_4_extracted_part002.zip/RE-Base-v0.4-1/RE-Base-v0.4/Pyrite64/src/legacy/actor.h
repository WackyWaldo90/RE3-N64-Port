#ifndef JILL_ACTOR_H
#define JILL_ACTOR_H
#include "engine.h"
void jill_init(void);
void jill_shutdown(void);
void jill_tick(int clip);
void jill_draw(surface_t *frame,float x,float y,float z,float heading);
int room_project_point(float x,float y,float z,float *sx,float *sy,float *depth);
#endif
