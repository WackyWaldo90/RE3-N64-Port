#ifndef RE3_BRIDGE_H
#define RE3_BRIDGE_H
#include "engine.h"
#ifdef __cplusplus
extern "C" {
#endif
void re3_room_init(void);
void re3_room_update(double elapsed, joypad_inputs_t input, joypad_buttons_t pressed);
void re3_room_draw(surface_t *frame);
void re3_room_shutdown(void);
#ifdef __cplusplus
}
#endif
#endif
