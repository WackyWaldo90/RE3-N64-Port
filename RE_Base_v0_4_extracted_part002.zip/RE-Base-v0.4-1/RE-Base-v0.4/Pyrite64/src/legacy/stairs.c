#include "stairs.h"
#include <math.h>
static float limit(float n,float lo,float hi){return fmaxf(lo,fminf(n,hi));}
void stair_move(StairBody *b,float dx,float dz,const StairRamp *r){
    b->x=limit(b->x+dx,r->x0,r->x1);
    b->z=limit(b->z+dz,r->z0+r->radius,r->z1-r->radius);
    float t=(b->x-r->x0)/(r->x1-r->x0);
    b->y=r->y0+(r->y1-r->y0)*t;
}
