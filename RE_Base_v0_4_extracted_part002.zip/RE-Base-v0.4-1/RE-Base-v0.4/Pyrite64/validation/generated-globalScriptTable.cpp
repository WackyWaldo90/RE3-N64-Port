// NOTE: Auto-Generated File!

#include <libdragon.h>

#include "script/globalScript.h"
#include "debug/debugMenu.h"

namespace P64::GlobalScript
{
    namespace C524533505952495 {
 void onSceneUpdate();
}
  namespace C524533505952495 {
 void onSceneDraw2D();
}
  namespace C524533505952495 {
 void onScenePostLoad();
}
  namespace C524533505952495 {
 void onScenePreUnload();
}
  namespace C524533505952495 {
 void onScenePreDraw();
}


  void callHooks(HookType type)
  {
    switch (type)
    {
      case HookType::SCENE_UPDATE:
  C524533505952495::onSceneUpdate();
 break;
case HookType::SCENE_DRAW_2D:
  C524533505952495::onSceneDraw2D();
 break;
case HookType::SCENE_POST_LOAD:
  C524533505952495::onScenePostLoad();
 break;
case HookType::SCENE_PRE_UNLOAD:
  C524533505952495::onScenePreUnload();
 break;
case HookType::SCENE_PRE_DRAW:
  C524533505952495::onScenePreDraw();
 break;


      default: break;
    }
  }
}
