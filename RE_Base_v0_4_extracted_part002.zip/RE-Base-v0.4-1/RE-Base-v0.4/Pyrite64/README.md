# Pyrite64 0.9.0 source integration — NOT A VALIDATED ROM

The earlier v0.4 playable ROM was written directly against libdragon. It did not use Pyrite64.
This directory adds a real .p64proj project and C++ lifecycle adapter. The uploaded Linux 0.9.0
editor was run in CLI mode against it. It parsed the project and scene and generated calls for
all five lifecycle hooks. Compilation stopped before target compilation at missing bin/mksprite.
No new ROM was produced, linked or emulated. Treat all runtime integration code as unverified.

## Applied source changes

- Pyrite owns the main loop, controller polling, VI buffers, DFS, audio mixer and presentation.
- RE3Runtime.cpp contains nonblocking warning (5 s), Capcom logo (3 s), opening movie
  (236 frames at 15 fps), soundtrack and warehouse phases. These intended behaviours need N64 tests.
- The warehouse event loop is exposed through room init/update/draw/shutdown functions.
  Movement remains on a 30 Hz accumulator. D-pad/stick, Z, L/R, A, B, C-Up, Start and the
  isolated C-Down stair diagnostic are retained in source.
- Jill mesh scale remains 0.65, palette intensity 65%, collision radius 400. Collision and
  stair solver source is identical to v0.4 and passes its existing host tests.
- Raw ROM data stays in payload/, with Makefile.custom dependencies to copy it into DFS.
- Original big-endian stereo PCM is converted to little-endian WAV for Pyrite/libdragon's
  wav64 asset pipeline. Playback uses Pyrite's audio manager instead of a second audio driver.
- Twenty-eight R101 backgrounds are decoded as PNGs under assets/room_reference for
  inspection in the asset browser. They are excluded from ROM conversion to avoid duplicate
  background payloads. The retained raw payload remains the runtime source.

## What this does not yet implement

Jill still uses the existing CPU diagnostic renderer. It is composed into an RGBA16 surface
and submitted through the RDP image blitter inside Pyrite's 2D hook. This does not turn Jill
into a tiny3d model or replace the game's collision solver with Pyrite physics.
The editor scene is a host for the custom RE3 runtime; its 3D viewport is not a reconstructed
warehouse level. Camera and collision records remain in src/legacy/generated/r101.json.
No performance improvement or 4 MB RAM compatibility has been measured for this adapter.
The isolated stairs, missing foreground masks, enemies, inventory and doors retain v0.4's limitations.

## Build

1. Use the uploaded Pyrite64 0.9.0 editor. Configure its N64 toolchain: libdragon preview v2,
   the corresponding N64 C/C++ compiler and tools, and a compatible tiny3d installation.
   This environment did not have that toolchain. The editor AppImage alone is insufficient.
2. Open project.p64proj. Set the project/toolchain path through the editor if required.
3. Build with F12, or:

       /absolute/path/to/pyrite64 --cli --cmd build /absolute/path/to/project.p64proj

4. The requested output is RE3_Pyrite64_UNVERIFIED.z64. That file is deliberately absent
   from this archive. Complete compilation and ares/gopher64 tests before treating it as usable.

The editor regenerates engine/, src/p64/, assets/p64/, filesystem/ and its main Makefile.
Custom rules live in Makefile.custom; handwritten source lives in src/user and src/legacy.
The command line must run with the editor's data and n64 directories available beside it.

## Required validation after a successful build

Verify startup timing and sound synchronisation; transition into the warehouse; all controls;
28 camera views; smaller/darker Jill; normal collision and isolated stair boundaries.
Check scene cleanup, repeated loads, asynchronous surface lifetime, wave stream cleanup,
frame pacing, peak RAM and ROM size. Confirm the display compositor works without tearing.
Profile before replacing the CPU renderer with tiny3d or changing original gameplay dimensions.
Current evidence is in validation/. Old validation-v04/ is only evidence for the original ROM.

## Provenance

Pyrite64: https://github.com/HailToDodongo/pyrite64 — Max Bebök (HailToDodongo), MIT.
Setup: https://hailtododongo.github.io/pyrite64/docs/manual/install.html
CLI: https://hailtododongo.github.io/pyrite64/docs/manual/cli.html
The project configuration follows the empty example distributed in the uploaded 0.9.0 AppImage.
The adapter and changes to the existing runtime fall under ../LICENSE-source.txt.
Capcom data retains its original ownership, as described there.
