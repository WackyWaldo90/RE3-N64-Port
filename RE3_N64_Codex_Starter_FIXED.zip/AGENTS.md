# Codex instructions — RE3 N64 Port

- Phase A first: audit repository, identify available toolchain, compile the minimal starter and boot in an N64 emulator. Capture logs and screenshot proof. No unverified success claims.
- Use the independent libdragon starter, **not** proprietary RE2 N64 executable or bootcode.
- M120 collision loader/banks live in `milestones/M120/` (if imported). Run `make -C milestones/M120 test` and preserve existing results.
- Phase B: inspect RDT/background/camera assets; implement a two-room fixed-camera proof of concept. Do not assume the collision bank contains backgrounds.
- Phase C: player model and tank movement; Phase D: collision/stairs; Phase E: door transitions; Phase F: combat/UI/audio/save.
- Treat reverse-engineering claims as VERIFIED, STATIC INFERENCE, or OPEN. Record provenance.
- Do not commit retail BIN/ISO/ROM, secrets, copyrighted video or audio; keep source assets in private authorized storage.
- If network or toolchain unavailable, report exact blocker and instructions rather than retrying indefinitely.
