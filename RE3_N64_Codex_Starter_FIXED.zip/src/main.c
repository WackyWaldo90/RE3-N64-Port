/* Independent N64 diagnostic starter. Requires libdragon SDK. */
#include <libdragon.h>
int main(void) {
    display_init(RESOLUTION_320x240, DEPTH_16_BPP, 2, GAMMA_NONE, FILTERS_RESAMPLE);
    controller_init();
    while (1) {
        controller_scan();
        struct controller_data keys = get_keys_down();
        if (keys.c[0].start) { /* Input confirmed: leave running */ }
        surface_t *surface = display_get();
        if (!surface) continue;
        graphics_fill_screen(surface, graphics_make_color(12, 22, 35, 255));
        graphics_draw_text(surface, 24, 35, "RE3 N64 - STARTER");
        graphics_draw_text(surface, 24, 55, "Independent libdragon prototype");
        graphics_draw_text(surface, 24, 75, "Phase A: boot and input test");
        display_show(surface);
    }
}
