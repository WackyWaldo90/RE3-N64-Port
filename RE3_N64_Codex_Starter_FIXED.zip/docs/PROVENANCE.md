# Provenance and limitations

`milestones/M120` copied from the existing local RE3 Codex Workspace, itself derived from the M120 milestone. Host tests must be rerun after import. The independently authored `src/main.c` is a starter, not code from the retail RE2 N64 ROM. Upstream SDK source is not bundled. Do not distribute proprietary PS1/N64 disc images.
