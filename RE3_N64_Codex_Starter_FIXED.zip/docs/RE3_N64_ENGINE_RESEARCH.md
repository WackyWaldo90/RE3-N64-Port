# RE3 N64 ENGINE RESEARCH AND CODEX HANDOFF

**Research snapshot:** 25 October 2026. **Evidence:** verified file inventory, local project documents, and named upstream references. No claims of having executed the retail game or N64 emulator in this session.

## 1. Architecture decision
Create an independent C-based Nintendo 64 prototype using libdragon, treating *Resident Evil 2 (Nintendo 64)* as an engineering and hardware reference, **not as a licensed reusable engine**. Copying the RE2 ROM header, executable, bootcode, or engine would not create a lawful or technically maintainable blank ROM. Start with a clean startup and display test.

## 2. Source locations and access boundaries
- GitHub project: https://github.com/WackyWaldo90/RE3-N64-Port ; README.md was readable. Previous GitHub integration writes returned HTTP 403; Codex GitHub authorization must be configured independently.
- Google Drive project root: https://drive.google.com/drive/folders/1uVm4YKG42ZFodwde0DCWLKXYzLVRr1W3 ; contains `RE3`, `Emulators`, `Tools`, `Roms`.
- RE3 Drive milestones: https://drive.google.com/drive/folders/1_CJSbPlElT1ScldYqPJQGGi2ItQsBz9X ; inspected listing includes M93–M119 and the RE3 Europe research manual.
- Dropbox: `/Source/resident evil 64&ps1` ; confirmed filenames include `Resident Evil 3 - Nemesis (Europe).bin` (712,491,360 bytes), `.cue`, `Resident_Evil_2_PS1_to_N64_Engineering_Guide.pdf`, `Resident_Evil_3_PS1_to_N64_Engineering_Guide.pdf`, `RE2_N64_Port_Asset_and_Conversion_Reference.pdf`, `ares-source.tar.gz`, `pcsx-redux-main`, `Pyrite64`, `RE-Base-v0.4`, and RE2 Europe PS1 archive. **The three Dropbox guides were located by metadata but their contents were not retrieved in this session.** Do not present their specific findings as read or verified.
- ChatGPT Library: access is not inherited by Codex; explicitly export/upload authorized files. Existing `RE3 Codex Workspace.zip` and M120 are available in this conversation runtime, not automatically in GitHub.

## 3. RE3 PS1 European executable and file formats
The local `RE3_Europe_PS1_Complete_Research_Reference_Manual.pdf` identifies `SLES_025.29`, executable size 876,544 bytes, SHA256 `c6024838b724a61bfda1bd9f239967bbeb96b57f969c4b34581602027a252ba8`, PS-X EXE load address `0x80010000`, and payload offset `0x800`. This manual is a project-authored secondary source; verify against the original executable when available.

Project milestones: M93 ARD-embedded RDT extraction; M95 RDT camera/collision structural audit; M97 R100 camera reconstruction; M100 SCA bitfields; M101–M116 slope/stair/collision and PS1 runtime investigations; M117 168 `.r3sc` converted collision files; M118 C99 collision loader; M119 room manager; M120 ROM-style collision bank. **Custom R3SC is not an official N64/RE2 data format.** Reported corpus: 169 RDT rooms, 168 nonempty SCA rooms, 5,291 SCA records. Check source scripts and CSVs before relying on counts.

## 4. Public RE3 / Bio3 technical references
- MeganGrass `bio-lib` Bio3 SCA reference: https://github.com/MeganGrass/bio-lib/blob/main/Bio3/SCA/bio3_sca.h ; use as a source to compare SCA record layout and semantics, pin a commit and check license.
- PCSX-Redux debugger/emulator: https://github.com/grumpycoders/pcsx-redux ; for PS1 MIPS traces, runtime addresses, room changes and camera behavior.
- libdragon N64 SDK: https://github.com/DragonMinded/libdragon ; N64 display/input/audio/filesystem toolchain. Confirm maintained toolchain version and APIs.
- ares emulator: https://github.com/ares-emulator/ares ; independent N64 runtime checks.
These are source links and proposed technical references, not proof of behavior observed in this session.

## 5. PS1 -> N64 asset conversion playbook (engineering hypotheses pending guide review)
| Asset/system | PS1 input | N64 target approach | Required proof |
|---|---|---|---|
| Room data | ARD/RDT, SCD, camera and SCA tables | Parse into versioned, endian-explicit room banks | Count/offset checks and room transition tests |
| Backgrounds | PS1 TIM/VRAM images and camera-linked views | Convert to N64-compatible textures (e.g., RGBA16 or CI8 where appropriate), tile or stream to fit memory | Pixel comparison, masking and RDRAM usage |
| Masks | Room foreground masks/depth rules | Camera-linked textured foreground geometry or masked overlays | Jill occlusion screenshots |
| Models | PS1 TMD/EMD/PLD mesh/rig/animation | Convert coordinates, topology, UV/color data and animations to compact N64-friendly vertex buffers | Side-by-side pose/animation comparisons |
| Collision | RDT SCA records | M117–M120 custom R3SC banks plus runtime collision resolver | Wall/stairs tests in emulator |
| Script/event logic | SCD instructions, room flags | Reimplement supported opcodes and save flags in portable C | Branch/door/trigger behavior tests |
| Audio | XA, VAB/VH/VB and sequenced tracks | Decode offline and transcode to supported N64 audio assets; budget DMA and CPU | Audio synchronization and memory metrics |
| FMV | STR/MDEC | Decode offline, rescale, compress into cartridge-friendly video/audio stream | Frame timing, quality and ROM size measurements |
| Save | PS1 memory card state | Define N64 save abstraction and cartridge save type | Save/reload integrity |

These are proposed conversion techniques, **not quotes from the three Dropbox guides**. Codex should ingest the actual guide PDFs and add page-numbered findings before selecting irreversible asset formats.

## 6. RE2 N64 comparison checklist
Study the RE2 N64 ROM **locally with user-supplied lawful copy** to measure ROM size, save type, texture formats, room streaming, fixed-camera background compression, geometry, animation, audio and FMV. Document actual extracted evidence rather than assuming Angel Studios' internal techniques. Do not transplant the retail executable or copyrighted assets into the starter.

## 7. N64 constraints and budgets
Plan for a 4 MiB baseline RDRAM with optional 8 MiB Expansion Pak support; exact memory map, video buffers, code/data heaps and ROM capacity must be measured for chosen hardware profile. N64 texture memory (TMEM) is 4 KiB and requires tiling/texture load planning. Cartridge streaming is not CD streaming: track DMA latency, bank offsets, alignment, decompression scratch space and worst-case room switch. Never claim that all RE3 content will fit without measured compression and ROM budgeting.

## 8. Phases and acceptance gates
A: Toolchain audit, host tests, compile starter, emulator boot proof. B: two rooms, fixed cameras, backgrounds, masks. C: Jill controller and animations. D: SCA collision and stairs. E: doors and stable room transitions. F: combat, AI, HUD, inventory, audio and saving. Require artifacts and emulator evidence at each gate.

## 9. Open issues
- No N64 cross-compiler or emulator detected in this execution environment, therefore no validated `.z64` produced here.
- The Dropbox PS1-to-N64 guide PDFs have been identified but not downloaded/read; their specific recommendations remain unverified.
- RE2 N64 proprietary engine not extracted or ported; cannot honestly call this an RE2-engine-based ROM.
- No verified conversion of RE3 backgrounds, full models, FMVs, audio or game scripting into running N64 assets in this starter.
- GitHub upload is not confirmed because prior integration returned 403 for writes.
