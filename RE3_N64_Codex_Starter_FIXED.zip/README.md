# RE3 N64 — independent starter

This package combines a **proposed** libdragon N64 diagnostic starter with the **previously tested host-side M120 collision workspace**. It is not the original RE2 N64 engine.

## Build
1. Install a compatible libdragon toolchain in the Codex environment (see https://github.com/DragonMinded/libdragon and its build docs). Set `N64_INST` to the toolchain installation directory.
2. Check the `Makefile` against the pinned libdragon version: API and Makefile conventions may differ. Adjust as needed.
3. `make` to attempt `build/re3_starter.z64`.
4. Boot it in ares or another N64 emulator and save logs/screenshots.
5. `make -C milestones/M120 test` to run host tests independently of N64 compilation.

**ROM status:** no bootable ROM is included. The available environment lacks an N64 compiler and emulator. A blank header or copied retail ROM would not count as a verified starter.
