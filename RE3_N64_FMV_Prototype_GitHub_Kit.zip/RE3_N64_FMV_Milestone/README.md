# RE3 N64 — opening FMV codec milestone (prototype)

**Status: PC-side encoder and portable C decoder implemented and tested; no N64 ROM built or emulator-tested.**

## Contents
- `tools/encode_fmv.py`: FFmpeg-based PC-side video converter (160x120, 10 fps default, RGB565 big-endian).
- `src/r3v1.c` and `src/r3v1.h`: freestanding-friendly RLE frame decoder in C; no heap allocation.
- `tests/test_codec.py`: six unit tests, including compiled C decoder round trips.
- `demo_synthetic.r3v`: generated non-game test clip. **Not Resident Evil footage**.

## Convert an authorised local copy of the RE3 intro

```bash
python3 tools/encode_fmv.py /private/path/to/intro.mp4 build/re3_intro.r3v --width 160 --height 120 --fps 10 --max-seconds 15
python3 -m unittest discover -s tests -v
```

The original PlayStation STR may require demuxing with specialised PS1 tools before FFmpeg can decode it; an MP4 intermediate is supported. This converter does not extract STR data from a game disc.

## R3V1 stream format
- 14-byte header: `R3V1`, width u16BE, height u16BE, fps u16BE, frame_count u32BE.
- Per frame: u32BE packet length, then RLE commands.
- Opcode 0–127: (opcode+1) literal RGB565 big-endian pixels.
- Opcode 128–255: (opcode-127) copies of next RGB565 pixel.
- The decoder validates packet boundaries and output size.

## N64 integration checklist
1. Integrate C decoder with the `WackyWaldo90/libdragon` build; create an actual Makefile and bootable ROM project.
2. Load encoded data from ROM filesystem or a ROM segment, **stream one frame at a time**. At 160x120 RGB565 a decoded frame needs 38,400 bytes; two frames need 76,800 bytes.
3. Decode into a suitable CPU-accessible RGB565 surface; blit/scale to N64 framebuffer and present at requested frame rate.
4. Add controller Start/A skip; then transition to splash/menu. Ensure no game assets are publicly committed.
5. For actual FMV soundtrack, add separately encoded mono ADPCM audio and A/V sync. **Audio is not implemented here**.
6. Build `.z64`, verify header/checksum, then test on Ares or Mupen64Plus; collect boot log and screenshots.

## RE2 N64 historical lessons
Angel Studios' RE2 N64 port demonstrates substantial cinematic compression and custom playback are feasible, but its actual proprietary codec and precise bitrates are not replicated here. This RLE RGB565 approach is an original *baseline codec*, best for low-motion synthetic test footage; photographic FMV may compress poorly. Production should benchmark block/DCT-based compression and N64 CPU/ROM bandwidth, then choose a measured codec.

## Limitations
No original RE3 intro is present in this local build workspace. N64 cross-compiler and N64 emulator are not installed here. The included sample is a synthetic moving test pattern. Do not label it an RE3 intro or a bootable `.z64`.
