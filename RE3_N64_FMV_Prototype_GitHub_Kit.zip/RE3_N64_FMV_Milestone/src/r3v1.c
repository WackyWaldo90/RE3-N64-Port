#include "r3v1.h"
#include <string.h>
int r3v1_decode_frame(const uint8_t *src,size_t src_len,uint8_t *dst,size_t pixels){
    size_t i=0,o=0;
    if(!src||!dst)return -1;
    while(i<src_len){
        uint8_t op=src[i++];
        size_t n=(op<128)?(size_t)op+1:(size_t)op-127;
        if(n>pixels-o)return -1;
        if(op<128){
            if(n>(src_len-i)/2)return -1;
            memcpy(dst+o*2,src+i,n*2);i+=n*2;
        }else{
            if(src_len-i<2)return -1;
            uint8_t hi=src[i++],lo=src[i++];
            for(size_t j=0;j<n;j++){dst[(o+j)*2]=hi;dst[(o+j)*2+1]=lo;}
        }
        o+=n;
    }
    return o==pixels?0:-1;
}
