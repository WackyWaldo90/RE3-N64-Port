#ifndef R3V1_H
#define R3V1_H
#include <stdint.h>
#include <stddef.h>
/* Decode one R3V1 frame payload to exactly pixel_count RGB565 pixels.
 * Returns 0 on success, -1 for invalid input. Big-endian bytes preserved.
 * Caller parses 14-byte header and 4-byte frame lengths. */
int r3v1_decode_frame(const uint8_t *src,size_t src_len,uint8_t *dst,size_t pixel_count);
#endif
