#!/usr/bin/env python3
"""Encode RGB565 BE frames as a deterministic N64-friendly RLE video stream.
Format: magic R3V1, width u16be, height u16be, fps u16be, frame_count u32be,
then for each frame: payload length u32be, followed by commands.
Commands: 0..127 => copy (opcode+1) literal pixels (2 bytes each);
128..255 => repeat next 2-byte pixel (opcode-127) times.
This is a prototype codec, not Angel Studios' proprietary codec.
"""
import argparse, pathlib, struct, subprocess
HEADER = '>4sHHHI'

def encode_frame(frame):
    if len(frame) % 2: raise ValueError('unaligned RGB565 frame')
    px=[frame[i:i+2] for i in range(0,len(frame),2)]
    out=bytearray(); i=0
    while i<len(px):
        run=1
        while i+run<len(px) and px[i+run]==px[i] and run<128: run+=1
        if run>=3:
            out.append(127+run);out.extend(px[i]);i+=run
        else:
            start=i;i+=run
            while i<len(px) and i-start<128:
                n=1
                while i+n<len(px) and px[i+n]==px[i] and n<128:n+=1
                if n>=3:break
                i+=min(n,128-(i-start))
            out.append(i-start-1);out.extend(b''.join(px[start:i]))
    return bytes(out)

def encode(frames, width, height, fps):
    if not (1<=width<=1024 and 1<=height<=1024 and 1<=fps<=60): raise ValueError('invalid dimensions/fps')
    output=bytearray(struct.pack(HEADER,b'R3V1',width,height,fps,len(frames)))
    for frame in frames:
        if len(frame)!=width*height*2:raise ValueError('invalid frame size')
        packet=encode_frame(frame)
        output.extend(struct.pack('>I',len(packet)));output.extend(packet)
    return bytes(output)

def main():
    p=argparse.ArgumentParser();p.add_argument('input');p.add_argument('output');p.add_argument('--width',type=int,default=160);p.add_argument('--height',type=int,default=120);p.add_argument('--fps',type=int,default=10);p.add_argument('--max-seconds',type=int,default=15)
    a=p.parse_args()
    if a.width%2: p.error('width must be even for yuv-compatible scaling')
    cmd=['ffmpeg','-v','error','-i',a.input,'-an','-t',str(a.max_seconds),'-vf',f'fps={a.fps},scale={a.width}:{a.height}:flags=lanczos,format=rgb565be','-f','rawvideo','-pix_fmt','rgb565be','pipe:1']
    raw=subprocess.check_output(cmd)
    framebytes=a.width*a.height*2
    if len(raw)%framebytes:raise RuntimeError('ffmpeg returned truncated frames')
    frames=[raw[i:i+framebytes] for i in range(0,len(raw),framebytes)]
    if not frames:raise RuntimeError('no decoded frames')
    pathlib.Path(a.output).write_bytes(encode(frames,a.width,a.height,a.fps))
    print(f'{len(frames)} frames; {len(raw)} raw bytes -> {pathlib.Path(a.output).stat().st_size} encoded bytes')
if __name__=='__main__':main()
