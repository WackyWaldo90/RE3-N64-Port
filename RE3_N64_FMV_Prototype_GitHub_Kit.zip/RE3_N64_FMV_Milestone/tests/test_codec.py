import pathlib,subprocess,sys,tempfile,unittest,ctypes,struct
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'tools'))
from encode_fmv import encode,encode_frame
class Codec(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();so=pathlib.Path(cls.tmp.name)/'r3v1.so'
  subprocess.run(['gcc','-shared','-fPIC','-Wall','-Wextra','-Werror','-o',str(so),str(ROOT/'src/r3v1.c')],check=True)
  cls.lib=ctypes.CDLL(str(so));cls.fn=cls.lib.r3v1_decode_frame;cls.fn.argtypes=[ctypes.c_void_p,ctypes.c_size_t,ctypes.c_void_p,ctypes.c_size_t];cls.fn.restype=ctypes.c_int
 @classmethod
 def tearDownClass(cls):cls.tmp.cleanup()
 def roundtrip(self,raw):
  packet=encode_frame(raw);src=ctypes.create_string_buffer(packet);dst=ctypes.create_string_buffer(len(raw));self.assertEqual(self.fn(src,len(packet),dst,len(raw)//2),0);self.assertEqual(dst.raw,raw)
 def test_solid(self):self.roundtrip(b'\xff\x00'*19200)
 def test_gradient(self):self.roundtrip(b''.join(struct.pack('>H',i%65536) for i in range(19200)))
 def test_mixed(self):self.roundtrip((b'\0\0'*128+b'\xff\xff'*2+b'\x12\x34'*50)*4)
 def test_header(self):
  data=encode([b'\0\0'*4],2,2,10);self.assertEqual(struct.unpack('>4sHHHI',data[:14]),(b'R3V1',2,2,10,1))
 def test_truncated(self):
  s=ctypes.create_string_buffer(b'\xff');d=ctypes.create_string_buffer(2);self.assertEqual(self.fn(s,1,d,1),-1)
 def test_bad_count(self):
  s=ctypes.create_string_buffer(b'\x80\x00\x00');d=ctypes.create_string_buffer(2);self.assertEqual(self.fn(s,3,d,0),-1)
if __name__=='__main__':unittest.main()
