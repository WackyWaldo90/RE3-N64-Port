import hashlib
import tempfile
import unittest
from pathlib import Path
from compiler.n64_gate import inspect_rom,check_evidence

class N64GateTests(unittest.TestCase):
    def test_n64_magic(self):
        for magic,kind in [(bytes.fromhex("80371240"),"z64"),(bytes.fromhex("37804012"),"v64"),(bytes.fromhex("40123780"),"n64")]:
            self.assertEqual(inspect_rom(magic+bytes(4092))["format"],kind)
    def test_reject_ps1_and_truncated(self):
        with self.assertRaises(ValueError):inspect_rom(b"PS-X EXE"+bytes(4096))
        with self.assertRaises(ValueError):inspect_rom(bytes.fromhex("80371240"))
    def test_no_false_emulator_certification(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'boot.log').write_text('manual placeholder')
            rom=bytes.fromhex('80371240')+bytes(4092);(p/'game.z64').write_bytes(rom)
            ev=dict(emulator='ares',emulator_version='test',rom_sha256=hashlib.sha256(rom).hexdigest(),rom_path='game.z64',boot_log='boot.log',booted_to_menu=True,tester='test',tested_at_utc='2026-10-25T00:00:00Z')
            result=check_evidence(ev,p)
            self.assertTrue(result['evidence_complete'])
            self.assertFalse(result['independently_verified'])
            ev['rom_sha256']='0'*64
            self.assertFalse(check_evidence(ev,p)['evidence_complete'])
    def test_path_traversal(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertFalse(check_evidence({'boot_log':'../other.log'},Path(d))['evidence_complete'])
