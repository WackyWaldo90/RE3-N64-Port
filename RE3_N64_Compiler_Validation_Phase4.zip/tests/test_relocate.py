import unittest
from compiler.rdt_compiler import inspect, sha256
from compiler.relocate import plan

class RelocateTests(unittest.TestCase):
    def setUp(self):
        b=bytearray(192)
        b[9*4:10*4]=(96).to_bytes(4,'little')
        b[18*4:19*4]=(128).to_bytes(4,'little')
        b[20*4:21*4]=(160).to_bytes(4,'little')
        b[100:104]=(164).to_bytes(4,'little')
        self.src=bytes(b)
        self.args=dict(expected_sha256=sha256(self.src))
    def test_grow_header_and_fixup(self):
        out,rep=plan(self.src,18,b'A'*40,fixups=[{'location':100,'target':164}],**self.args)
        self.assertEqual(len(out),200)
        self.assertEqual(int.from_bytes(out[20*4:21*4],'little'),168)
        self.assertEqual(int.from_bytes(out[100:104],'little'),172)
        self.assertEqual(rep['delta'],8)
    def test_shrink(self):
        out,_=plan(self.src,18,b'B'*24,**self.args)
        self.assertEqual(len(out),184)
        self.assertEqual(int.from_bytes(out[80:84],'little'),152)
    def test_hash_required(self):
        with self.assertRaises(ValueError):plan(self.src,18,b'A'*40)
    def test_bad_alignment(self):
        with self.assertRaises(ValueError):plan(self.src,18,b'A'*39,**self.args)
    def test_invalid_fixup(self):
        with self.assertRaises(ValueError):plan(self.src,18,b'A'*40,fixups=[{'location':100,'target':165}],**self.args)
    def test_no_alias(self):
        b=bytearray(self.src);b[19*4:20*4]=(128).to_bytes(4,'little')
        with self.assertRaises(ValueError):plan(bytes(b),18,b'A'*40,expected_sha256=sha256(b))
    def test_no_internal_target(self):
        with self.assertRaises(ValueError):plan(self.src,18,b'A'*40,fixups=[{'location':100,'target':132}],**self.args)
    def test_no_equal_length(self):
        with self.assertRaises(ValueError):plan(self.src,18,b'A'*32,**self.args)

if __name__=='__main__':unittest.main()
