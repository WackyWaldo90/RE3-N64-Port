# Resident Evil 3 Nintendo 64 — RDT compiler validation kit (Phase 4)

**TARGET: Nintendo 64.** Original PS1 RE3 files are **inputs**, not the finished game. This kit does not build a complete N64 ROM, convert all SCD logic, or grant emulator verification.

## Components

- `compiler/rdt_compiler.py`: byte-preserving RE3 source RDT inspection and size-preserving patching.
- `compiler/relocate.py` and `relocate_cli.py`: experimental relocation requiring explicit fixups; unknown references can make outputs unsafe.
- `compiler/corpus_validate.py`: read-only audit of private extracted RDT files.
- `compiler/n64_gate.py`: N64 ROM magic/size/hash preflight, plus structured **N64 emulator** evidence completeness checks. The evidence checker deliberately never marks independent verification true.
- `.github/workflows/rdt-compiler-validation.yml`: synthetic tests only.

## Run tests

```sh
python -m unittest discover -s tests -v
```

## Audit private RDTs

```sh
python -m compiler.corpus_validate /private/re3-rdts --report /private/rdt_audit.json --expect-count 169
```

## N64 ROM preflight (when an N64 toolchain has built a ROM)

```sh
python -m compiler.n64_gate --rom /private/build/re3.z64
```

This checks header byte order, minimum size, and SHA-256. It does NOT check N64 bootcode integrity, CIC-specific CRC correctness, or actual boot success.

## N64 emulator test evidence

Run the produced `.z64` in **ares or Mupen64Plus**, capture a real log/video/screenshots, and observe the RE3 splash/menu. Prepare a private `evidence.json`:

```json
{
  "emulator": "ares",
  "emulator_version": "FILL_ACTUAL_VERSION",
  "rom_sha256": "FILL_REAL_64_CHAR_SHA256",
  "rom_path": "re3.z64",
  "boot_log": "n64_boot.log",
  "booted_to_menu": true,
  "tester": "FILL_TESTER",
  "tested_at_utc": "FILL_UTC_TIMESTAMP"
}
```

Paths are relative to the evidence file; keep ROMs, game assets, logs, and evidence **private**. Run:

```sh
python -m compiler.n64_gate --evidence /private/evidence.json --output /private/n64_evidence_report.json
```

The report says `evidence_complete` (metadata present), **not independently verified**. A human must review actual emulator output. A bootable ROM and RE3 main menu remain future milestones. No PS1 disc rebuild or PS1 emulator test is required as the final acceptance gate.

## GitHub installation

Extract this ZIP into the **root** of `WackyWaldo90/RE3-N64-Port` rather than uploading only the ZIP. Preserve existing files; reconcile changes before overwriting. No proprietary assets are included. The existing RDT compiler modules are kept unchanged, while the old PS1-specific evidence gate is replaced by `n64_gate.py`.
