"""Read-only RDT corpus audit. No proprietary bytes are exported."""
import argparse, hashlib, json, pathlib, sys
from .rdt_compiler import inspect, build

def audit(root):
    paths=sorted(root.rglob('*.RDT'))+sorted(root.rglob('*.rdt'))
    paths=sorted(set(paths))
    results=[]
    for path in paths:
        row={'file':str(path.relative_to(root))}
        try:
            data=path.read_bytes()
            parsed=inspect(data)
            roundtrip=build(data,[])
            row.update({'ok':roundtrip==data,'sha256':hashlib.sha256(data).hexdigest(),'size':len(data),'pointer_count':len(parsed['section_bounds'])})
        except Exception as exc:
            row.update({'ok':False,'error':str(exc)})
        results.append(row)
    return {'files':len(results),'passed':sum(x['ok'] for x in results),'failed':sum(not x['ok'] for x in results),'results':results,'note':'No-edit copy test only. Not evidence that edited rooms boot in a PS1 emulator.'}

def main():
    p=argparse.ArgumentParser();p.add_argument('directory',type=pathlib.Path);p.add_argument('--report',type=pathlib.Path,default=pathlib.Path('rdt_audit.json'));p.add_argument('--expect-count',type=int,default=169)
    a=p.parse_args();report=audit(a.directory);a.report.write_text(json.dumps(report,indent=2));print(f"RDT: {report['passed']}/{report['files']} passed, expected {a.expect_count}");return 0 if report['files']==a.expect_count and not report['failed'] else 1
if __name__=='__main__':sys.exit(main())
