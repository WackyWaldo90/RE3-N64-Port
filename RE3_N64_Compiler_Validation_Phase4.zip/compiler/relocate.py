"""Experimental explicit RDT span relocator; unknown internal references are NOT inferred.

Safety model: relocation only with a caller-supplied manifest of *all* affected
internal pointer locations. Until independently verified against RE3 rooms this
is a research tool, not a production RDT compiler.
"""
import hashlib
import json
from .rdt_compiler import HEADER_SIZE, POINTER_COUNT, inspect, sha256


def plan(source, index, replacement, *, alignment=4, fixups=(), expected_sha256=None):
    """Rebuild the span beginning at a top-level pointer, updating header pointers.

    fixups: explicit list of {location, target, width?} where location is the
    original absolute file offset of a little-endian internal pointer field,
    target is its original absolute file offset, and width defaults to 4.
    Locations inside the replaced span are forbidden: caller must rebuild them.
    This is NOT automatic discovery of internal references.
    """
    if expected_sha256 is None or expected_sha256 != sha256(source):
        raise ValueError('expected_sha256 must match source')
    if not isinstance(index, int) or isinstance(index, bool) or not 1 <= index < POINTER_COUNT:
        raise ValueError('index must be an RDT pointer index from 1 to 23')
    if not isinstance(alignment, int) or isinstance(alignment, bool) or alignment not in (1, 2, 4, 8, 16):
        raise ValueError('unsupported alignment')
    if not isinstance(replacement, bytes) or not replacement:
        raise ValueError('replacement must be nonempty bytes')
    info = inspect(source)
    pointers = [int.from_bytes(source[i*4:i*4+4], 'little') for i in range(POINTER_COUNT)]
    start = pointers[index]
    if not start:
        raise ValueError('selected section is absent')
    ends = sorted({p for p in pointers[1:] if p > start})
    end = ends[0] if ends else len(source)
    if any(p == start for i, p in enumerate(pointers) if i not in (0, index)):
        raise ValueError('aliased section start: relocation requires manual review')
    if start % alignment or end % alignment or len(replacement) % alignment:
        raise ValueError('alignment violation')
    delta = len(replacement) - (end - start)
    if delta == 0:
        raise ValueError('use the original size-preserving patcher for same-size edits')
    result = bytearray(source[:start] + replacement + source[end:])
    for i in range(1, POINTER_COUNT):
        p = pointers[i]
        if p > start and p < end:
            raise ValueError(f'header pointer {i} targets interior of resized span')
        if p >= end:
            new = p + delta
            if new < HEADER_SIZE or new >= len(result) or new > 0xffffffff:
                raise ValueError('relocated header pointer out of bounds')
            result[i*4:i*4+4] = new.to_bytes(4, 'little')
    seen = set()
    for f in fixups:
        loc, target, width = f['location'], f['target'], f.get('width', 4)
        if width != 4 or not isinstance(loc, int) or not isinstance(target, int):
            raise ValueError('only explicit u32 fixups are supported')
        if loc < HEADER_SIZE or loc + width > len(source) or loc < end and loc + width > start:
            raise ValueError('fixup location overlaps replaced section or is out of range')
        if loc in seen or any(loc < x+4 and loc+4 > x for x in seen):
            raise ValueError('overlapping fixups')
        seen.add(loc)
        if target < HEADER_SIZE or target >= len(source) or start <= target < end:
            raise ValueError('fixup target is invalid or within replaced section')
        if int.from_bytes(source[loc:loc+4], 'little') != target:
            raise ValueError('original fixup value does not match declared target')
        newloc = loc + (delta if loc >= end else 0)
        newtarget = target + (delta if target >= end else 0)
        result[newloc:newloc+4] = newtarget.to_bytes(4, 'little')
    inspect(result)
    return bytes(result), {'section_index': index, 'old_span': [start,end], 'new_span': [start,start+len(replacement)], 'delta': delta, 'header_pointers_updated': sum(1 for p in pointers[1:] if p >= end), 'explicit_fixups': len(seen), 'warning': 'EXPERIMENTAL: unknown internal references are not automatically discovered; do not use rebuilt files in game without independent validation'}
