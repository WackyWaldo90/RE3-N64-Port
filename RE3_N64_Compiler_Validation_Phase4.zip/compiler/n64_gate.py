"""N64 ROM format preflight and conservative emulator evidence gate.

An evidence manifest is NOT proof of emulator execution; independent review is required.
"""
import argparse
import hashlib
import json
from pathlib import Path

MAGIC = {b"\x80\x37\x12\x40": "z64", b"\x37\x80\x40\x12": "v64", b"\x40\x12\x37\x80": "n64"}

def inspect_rom(data):
    if len(data) < 0x1000:
        raise ValueError("ROM too short for cartridge header and bootcode")
    kind = MAGIC.get(data[:4])
    if not kind:
        raise ValueError("unknown N64 cartridge byte order/magic")
    return {"format":kind,"size_bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"header_crc1_crc2_raw":data[0x10:0x18].hex(),"warning":"Magic/header check only; not proof of valid checksums, executable boot or gameplay"}

def check_evidence(evidence, base):
    required=("emulator","emulator_version","rom_sha256","boot_log","booted_to_menu","tester","tested_at_utc")
    issues=[f"missing {k}" for k in required if not evidence.get(k)]
    h=evidence.get("rom_sha256","")
    if len(h)!=64 or any(c not in "0123456789abcdefABCDEF" for c in h):issues.append("invalid rom_sha256")
    if evidence.get("booted_to_menu") is not True:issues.append("booted_to_menu must be true")
    log=evidence.get("boot_log","")
    if not isinstance(log,str) or not log or Path(log).is_absolute() or ".." in Path(log).parts:
        issues.append("boot_log must be a relative path within evidence directory")
    elif not (base/log).is_file() or not (base/log).stat().st_size:
        issues.append("boot_log missing or empty")
    rom=evidence.get("rom_path")
    if rom:
        if not isinstance(rom,str) or Path(rom).is_absolute() or ".." in Path(rom).parts:
            issues.append("rom_path must be relative")
        else:
            try:
                actual=inspect_rom((base/rom).read_bytes())
                if actual["sha256"].lower()!=h.lower():issues.append("ROM hash mismatch")
            except (OSError,ValueError) as ex:issues.append(f"ROM invalid: {ex}")
    return {"evidence_complete":not issues,"independently_verified":False,"issues":issues,"note":"Requires human review of authentic emulator log/video and actual gameplay; manifest alone never grants verification"}

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--rom",type=Path)
    p.add_argument("--evidence",type=Path)
    p.add_argument("--output",type=Path)
    a=p.parse_args(argv)
    if not a.rom and not a.evidence:p.error("provide --rom and/or --evidence")
    report={}
    try:
        if a.rom:report["rom_preflight"]=inspect_rom(a.rom.read_bytes())
        if a.evidence:report["emulator_evidence"]=check_evidence(json.loads(a.evidence.read_text()),a.evidence.parent)
    except (ValueError,OSError,json.JSONDecodeError) as ex:
        p.exit(2,f"ERROR: {ex}\n")
    result=json.dumps(report,indent=2)
    if a.output:a.output.write_text(result+"\n")
    print(result)
    return 1 if "emulator_evidence" in report and not report["emulator_evidence"]["evidence_complete"] else 0

if __name__=="__main__":raise SystemExit(main())
