"""Run as: python -m compiler.relocate_cli original.rdt replacement.bin manifest.json output.rdt"""
import argparse
import json
from pathlib import Path
from .rdt_compiler import sha256
from .relocate import plan

def main():
    p = argparse.ArgumentParser(description=__doc__)
    for arg in ('source','replacement','manifest','output'):
        p.add_argument(arg, type=Path)
    a = p.parse_args()
    if a.source.resolve() == a.output.resolve():
        p.error('refusing to overwrite source')
    source = a.source.read_bytes()
    spec = json.loads(a.manifest.read_text())
    result, report = plan(source, spec['section_index'], a.replacement.read_bytes(), alignment=spec.get('alignment',4), fixups=spec.get('fixups',[]), expected_sha256=spec['source_sha256'])
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_bytes(result)
    print(json.dumps({**report,'source_sha256':sha256(source),'output_sha256':sha256(result)},indent=2))

if __name__ == '__main__':
    main()
