# RE3 Codex Workspace

A Codex-ready **source and test workspace** assembled from the locally verified `RE3_M120_ROM_Bank_Streaming.zip` milestone. It is **not a compiled N64 ROM or complete RE3 asset extraction**.

## Start here
- Read [`AGENTS.md`](AGENTS.md) for the phased implementation plan and acceptance gates.
- Run `make test` (host GCC + Python 3).
- Source and test data are under `milestones/M120/`.
- Review `docs/PHASE_PLAN.md` and `docs/STATUS.md`.

## Why not just a ZIP in GitHub?
Codex needs the **extracted repository files** to work effectively. Upload/extract this ZIP into the GitHub repository; committing the ZIP alone is not enough.

## Toolchain
Host: Python 3, GCC/Clang, Make. N64: libdragon/N64 SDK and emulator **must still be installed and validated by Codex**. No emulator or SDK binary is included.
