# RE3 N64 character runtime — collision hardening and verification gate

This patch improves the portable character controller by dividing each movement frame into collision-tested substeps (maximum half the actor radius). It prevents the previous controller's thin-wall tunneling failure. It retains synthetic stair interpolation and five actor role tests. `make test` compiles with strict C99 warnings and runs the tests on a host PC.

`python3 scripts/verify_n64.py --rom path/to/re3.z64 --evidence path/to/evidence.json` **fails closed** when a ROM or actual emulator evidence is missing. Evidence JSON must contain `rom_sha256`, `emulator` (`ares` or `mupen64plus`), `boot_verified`, `menu_verified`, `controller_verified` (all true), and `emulator_log_path` pointing to a real log. This checks evidence completeness and hash consistency, **not authenticity**: manual inspection of emulator screenshots and logs is mandatory.

## Not yet complete
- No N64 compiler/emulator was available in this execution environment.
- No RE3 native `.z64` build or N64 emulator boot was performed.
- No real RDT/SCA collision, original character animation bank, or staircase SCD data is connected.
- No FMV player is integrated into a ROM.

## Integration
Copy `include/re3_actor.h` and `src/re3_actor.c` into `engine/character/` (adjust include paths); merge tests into existing CI rather than replacing other build files. Keep game ROMs and assets private. Next: link real RE3 room collision and actual animations, cross-compile with libdragon, boot a ROM in Ares and record evidence.
