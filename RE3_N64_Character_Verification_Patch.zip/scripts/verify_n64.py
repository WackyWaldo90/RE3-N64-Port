#!/usr/bin/env python3
"""Fail-closed ROM and emulator evidence gate. Does not run an emulator."""
import argparse, hashlib, json, pathlib, sys
p=argparse.ArgumentParser()
p.add_argument('--rom', required=True)
p.add_argument('--evidence', required=True, help='JSON evidence from actual emulator execution')
a=p.parse_args()
rom=pathlib.Path(a.rom)
if not rom.is_file(): sys.exit('FAIL: ROM missing')
data=rom.read_bytes()
if len(data)<0x1000 or data[:4]!=bytes.fromhex('80371240'): sys.exit('FAIL: invalid .z64 magic/size')
if len(data)%4: sys.exit('FAIL: ROM length not word aligned')
e=pathlib.Path(a.evidence)
if not e.is_file(): sys.exit('FAIL: emulator evidence missing')
v=json.loads(e.read_text())
sha=hashlib.sha256(data).hexdigest()
if v.get('rom_sha256')!=sha: sys.exit('FAIL: evidence ROM hash mismatch')
if v.get('emulator') not in ('ares','mupen64plus'): sys.exit('FAIL: unsupported emulator name')
if not all(v.get(k) is True for k in ('boot_verified','menu_verified','controller_verified')):
 sys.exit('FAIL: boot/menu/controller verification incomplete')
if not v.get('emulator_log_path') or not pathlib.Path(v['emulator_log_path']).is_file():
 sys.exit('FAIL: actual emulator log missing')
print('PASS: evidence fields and ROM hash match; independently inspect logs/screenshots before release')
