#!/usr/bin/env python3
"""Read-only RE2 N64 reference ROM audit; no copyrighted bytes exported."""
import argparse, hashlib, json, struct
from pathlib import Path
MAGICS={bytes.fromhex('80371240'):'z64',bytes.fromhex('37804012'):'v64',bytes.fromhex('40123780'):'n64'}
def normalized_header(h):
    magic=h[:4]; mode=MAGICS.get(magic)
    if mode is None: raise ValueError('Unknown N64 ROM byte order')
    if mode=='z64': return h,mode
    if mode=='v64': return bytes(y for i in range(0,len(h),2) for y in (h[i+1],h[i])),mode
    return bytes(y for i in range(0,len(h),4) for y in h[i:i+4][::-1]),mode
def audit(path):
    path=Path(path); size=path.stat().st_size
    if size<0x1000: raise ValueError('ROM shorter than 4 KiB boot area')
    with path.open('rb') as f:
        h=f.read(0x1000); f.seek(0); sha=hashlib.sha256()
        for chunk in iter(lambda:f.read(1024*1024),b''): sha.update(chunk)
    hdr,mode=normalized_header(h)
    return {'source_type':'reference_rom','reference_only':True,'size_bytes':size,'sha256':sha.hexdigest(),'byte_order':mode,'title':hdr[0x20:0x34].decode('ascii','replace').strip(),'game_code':hdr[0x3b:0x3f].decode('ascii','replace'),'entrypoint':'0x%08X'%struct.unpack_from('>I',hdr,8)[0],'crc1':'0x%08X'%struct.unpack_from('>I',hdr,0x10)[0],'crc2':'0x%08X'%struct.unpack_from('>I',hdr,0x14)[0],'boot_region_sha256':hashlib.sha256(hdr[0x40:0x1000]).hexdigest(),'emulator_verified':False,'n64_port_built':False}
def main():
    p=argparse.ArgumentParser();p.add_argument('rom');p.add_argument('--out');a=p.parse_args(); result=audit(a.rom); data=json.dumps(result,indent=2)+'\n'
    if a.out: Path(a.out).write_text(data)
    else: print(data,end='')
if __name__=='__main__':main()
