# RE3 N64 — reference ROM audit and repository integration

The `reports/re2_europe_reference.json` report was measured against the locally supplied RE2 N64 Europe `.z64` reference ROM. This is **not** an RE3 ROM or a claim of RE3 boot compatibility.

`python scripts/re2_n64_reference_audit.py /private/path/RE2.z64 --out /tmp/reference.json`

The script only emits header metadata and hashes; it does not extract or redistribute copyrighted ROM content. Never commit the ROM or ROM chunks to a public repository. The current GitHub repository already contains `rom_inventory.py` and `RE2_N64_ROM_parts_manifest.json`; this audit is complementary. Existing ROM part archives should be reviewed for licensing and removed from public hosting if not authorized.

## Priority integration

1. Treat `WackyWaldo90/biohazard-utils` and `WackyWaldo90/Tool_Hazard` as **independent format references**, not automatic dependencies. Verify RE3 RDT/SCD semantics and licensing before adapting code.
2. Keep the Phase 4 RDT compiler as an **experimental source-data tool**. Require genuine RDT round-trip tests, bounded pointer relocation and opaque-byte preservation before using its output in an N64 build.
3. Convert verified RE3 camera, collision, geometry, script and resource data to a versioned **N64-specific room pack**; do not load PS1 RDT binary layouts directly without explicit compatibility checks.
4. Implement N64-native boot, menu and room loader with a selected supported SDK; test in a real N64 emulator. Neither this audit nor a valid `.z64` header proves bootability.
5. Add reproducible CI for synthetic asset tests and ROM-header checks. Keep proprietary source data and emulator test assets private.

## Evidence and limitations

Reference: RE2 Europe N64 game code `NREP`, 64 MiB, original entrypoint `0x80000480`. Source hash is recorded in the JSON. No code/data extraction or emulator execution was performed by this audit.
