import unittest
from compiler.rdt_compiler import inspect,build

class RDTTests(unittest.TestCase):
    def setUp(self):
        b=bytearray(256)
        b[9*4:10*4]=(96).to_bytes(4,'little')
        b[18*4:19*4]=(128).to_bytes(4,'little')
        b[130:134]=b'ABCD'
        self.src=bytes(b)
    def test_roundtrip(self):
        self.assertEqual(build(self.src,[]),self.src)
    def test_section_bounds(self):
        spans=inspect(self.src)['section_bounds']
        self.assertEqual([(x['start'],x['end_upper_bound']) for x in spans],[(96,128),(128,256)])
    def test_patch(self):
        result=build(self.src,[{'offset':130,'expected_hex':'41424344','replacement_hex':'01020304'}])
        self.assertEqual(result[130:134],b'\x01\x02\x03\x04')
        self.assertEqual(result[:130]+result[134:],self.src[:130]+self.src[134:])
    def test_mismatch(self):
        with self.assertRaises(ValueError):build(self.src,[{'offset':130,'expected_hex':'0000','replacement_hex':'0102'}])
    def test_resize_rejected(self):
        with self.assertRaises(ValueError):build(self.src,[{'offset':130,'expected_hex':'41','replacement_hex':'0102'}])
    def test_header_patch_rejected(self):
        with self.assertRaises(ValueError):build(self.src,[{'offset':36,'expected_hex':'60','replacement_hex':'70'}])
    def test_bad_pointer(self):
        b=bytearray(self.src);b[36:40]=(900).to_bytes(4,'little')
        with self.assertRaises(ValueError):inspect(b)
    def test_overlap(self):
        with self.assertRaises(ValueError):build(self.src,[{'offset':130,'expected_hex':'4142','replacement_hex':'0102'},{'offset':131,'expected_hex':'4243','replacement_hex':'0304'}])

if __name__=='__main__':unittest.main()
