#!/usr/bin/env python3
"""Conservative RE3 PS1 RDT binary round-trip and size-preserving patcher.

This is stage 1, NOT a relocating/variable-length RDT assembler. It never
modifies a source file and refuses unsafe or unverified patches.
"""
import argparse
import hashlib
import json
import pathlib
import sys

HEADER_SIZE = 96
POINTER_COUNT = 24
SECTION_NAMES = {2:'VB',3:'VH',8:'SCA',9:'RID',10:'RVD',11:'LIT_PRI',12:'OBJ_TIM',13:'FLR',14:'BLK',15:'MSG',16:'RBJ',18:'SCD',19:'EFF',20:'SND',21:'EFFSPR',22:'TIM'}

def sha256(data):
    return hashlib.sha256(data).hexdigest()

def inspect(data):
    if len(data) < HEADER_SIZE:
        raise ValueError('RDT shorter than 96-byte header')
    # R3ditor-V2 App/js/rdt.js: first 8 bytes are metadata, then 23 LE u32 pointers.
    pointers = [int.from_bytes(data[i*4:i*4+4], 'little') for i in range(POINTER_COUNT)]
    valid = []
    for i, off in enumerate(pointers[1:], 1):
        if off == 0:
            continue
        if off < HEADER_SIZE or off >= len(data):
            raise ValueError(f'pointer {i} outside body: 0x{off:x} / {len(data)}')
        valid.append((i, off))
    unique = sorted(set(off for _,off in valid))
    spans = []
    for index, off in valid:
        end = next((v for v in unique if v > off), len(data))
        spans.append({'index':index,'name':SECTION_NAMES.get(index,'UNKNOWN'), 'start':off,'end_upper_bound':end,'length_upper_bound':end-off})
    return {'bytes':len(data),'sha256':sha256(data),'header_hex':data[:8].hex(),'pointers':pointers[1:], 'section_bounds':spans,'note':'End bounds are next-pointer upper bounds, NOT verified section lengths. Some sections may contain embedded data or aliases.'}

def build(source, patches):
    original = bytes(source)
    inspect(original)
    result = bytearray(original)
    ranges = []
    for patch in patches:
        off = patch['offset']
        if not isinstance(off,int) or isinstance(off,bool) or off < HEADER_SIZE:
            raise ValueError('patch offset must be an integer at or after 96-byte header')
        expected = bytes.fromhex(patch['expected_hex'])
        replacement = bytes.fromhex(patch['replacement_hex'])
        if not expected or len(expected) != len(replacement):
            raise ValueError('only nonempty, equal-length replacements supported')
        end = off + len(expected)
        if end > len(original):
            raise ValueError('patch exceeds file')
        if any(off < e and end > s for s,e in ranges):
            raise ValueError('overlapping patches')
        if original[off:end] != expected:
            raise ValueError(f'expected bytes mismatch at 0x{off:x}')
        ranges.append((off,end))
        result[off:end] = replacement
    return bytes(result)

def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest='command',required=True)
    for cmd in ('inspect','roundtrip','patch'):
        q=sub.add_parser(cmd)
        q.add_argument('source',type=pathlib.Path)
        if cmd != 'inspect':q.add_argument('output',type=pathlib.Path)
        if cmd == 'patch':q.add_argument('--patches',required=True,type=pathlib.Path,help='JSON with source_sha256 and patches list')
    a=p.parse_args(argv)
    source=a.source.read_bytes()
    report=inspect(source)
    if a.command=='inspect':
        print(json.dumps(report,indent=2));return 0
    if a.source.resolve()==a.output.resolve():
        raise ValueError('output must not overwrite source')
    if a.command=='roundtrip':
        result=build(source,[])
    else:
        spec=json.loads(a.patches.read_text())
        if spec.get('source_sha256') != sha256(source):
            raise ValueError('source_sha256 missing or incorrect')
        result=build(source,spec['patches'])
    if len(result)!=len(source):raise AssertionError('unexpected resize')
    inspect(result)
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_bytes(result)
    print(json.dumps({'source_sha256':sha256(source),'output_sha256':sha256(result),'bytes':len(result),'output':str(a.output)},indent=2))
    return 0

if __name__=='__main__':
    try:sys.exit(main())
    except (ValueError,KeyError,TypeError,OSError) as e:
        print(f'ERROR: {e}',file=sys.stderr);sys.exit(2)
