# R3ditor-V2 RDT Compiler — Phase 1 (conservative MVP)

**Status:** working/tested Python prototype for lossless round-trip and guarded equal-size binary edits. **NOT** a complete RE3 RDT compiler. It does not assemble SCD, change section sizes, relocate pointers, rebuild ARD, or prove in-game loading.

## Research basis

- `WackyWaldo90/R3ditor-V2`, `App/js/rdt.js`: 96-byte header, 24 four-byte entries; first entry is metadata, other entries are little-endian offsets. Its existing `compile` is explicitly WIP.
- User's Drive `M10-M11.md`: prior RE3 European RDT/SCD research, 169 bounded sections, 4,240 procedures, opaque-tail preservation. This prototype does not claim to reproduce those results.
- User's RE3 European BIN/CUE and research manual: reference corpus for later real-file tests.

## Commands

From this folder:

```bash
python3 -m unittest discover -s tests -v
python3 compiler/rdt_compiler.py inspect /private/R100.RDT
python3 compiler/rdt_compiler.py roundtrip /private/R100.RDT /private/out/R100.RDT
python3 compiler/rdt_compiler.py patch /private/R100.RDT /private/out/R100_modified.RDT --patches edits.json
```

Example `edits.json` (replace hash, offsets and bytes with real validated values):

```json
{"source_sha256":"64_CHARACTER_SHA256_OF_ORIGINAL", "patches":[{"offset":130,"expected_hex":"41424344","replacement_hex":"01020304"}]}
```

Never run against proprietary files in public CI. Keep original discs, RDTs and edited game assets private. Only commit code/tests to public GitHub. `inspect` reports next-pointer **upper bounds**, not authoritative section lengths. It does not reject all semantic invalidities. Never modify header pointers with this tool.

## Next phase

1. Run no-edit SHA-256 comparisons on all 169 real extracted RDTs (private corpus).
2. Cross-check R3ditor `rdt.js` with pinned `biorand/biohazard-utils` `Rdt2` and the milestone source manifests.
3. Implement per-section parsers and verified length fields, then variable-length SCD with relocation maps and preserved opaque tails.
4. Validate modified rooms by reopening in independent parser, rebuilding a private PS1 disc with `mkpsxiso`, and running emulator tests.
5. Add an R3ditor UI action only once the compiler is independently validated.
