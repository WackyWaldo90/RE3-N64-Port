#ifndef RE3_RUNTIME_H
#define RE3_RUNTIME_H
#include <stdint.h>
#include <stddef.h>
#define RE3_RDRAM_LIMIT_BYTES (4u * 1024u * 1024u)
typedef enum { RE3_BANK_ENGINE=0, RE3_BANK_ROOMS=1, RE3_BANK_GAMEPLAY=2, RE3_BANK_FMV=3 } re3_bank_t;
typedef struct { uint32_t id, rom_offset, packed_size, unpacked_size, crc32; uint16_t codec, flags; re3_bank_t bank; } re3_asset_entry_t;
typedef struct { size_t reserved, active, peak; } re3_memory_stats_t;
int re3_memory_can_reserve(size_t current, size_t requested);
int re3_asset_entry_valid(const re3_asset_entry_t *entry, uint32_t rom_size);
#endif
