# RE3 N64 engine integration — Codex work order

Target: standard N64, 4 MiB RDRAM, no Expansion Pak. Four *logical ROM regions* are not physical memory banks. Do not copy proprietary RE2 N64 code; implement behavioral equivalents.

## Acceptance gates
1. Install/pin libdragon, MIPS N64 compiler, ROM builder and emulator. Report exact versions.
2. Build a minimal bootable .z64 and verify it in emulator configured for 4 MiB RAM. Capture boot log and screenshot.
3. Implement modules: n64_boot, rom_bank, memory_manager, room_loader, background_renderer, model_renderer, collision, controller, audio_engine, menu_system, save_system.
4. Maintain manifest for 169 RDTs. R600 has zero extracted SCA records; preserve as special scene candidate, do not discard. Verify boutique mapping rather than assuming. Validate 168 collision-bearing rooms (5,291 records).
5. Room viewer: select room, cycle cameras, draw background/masks, overlay collision. Only mark complete after screenshot and emulator test.
6. Controller: A confirm/action, B run/cancel, Z aim, analog/D-pad movement, Start pause; configurable C buttons. Add RE3 quick-turn and dodge as gameplay rules.
7. Audio and menus: implement interfaces first, then test sound, inventory, item mixing, map, save/load.
8. Video/FMVs are LAST. Build non-FMV assets, measure ROM usage and peak RDRAM, then allocate remaining cartridge capacity with a safety margin.
9. One-command entrypoint: `make game` orchestrates preflight, conversion, compile, pack, test and reports; fail loudly on missing assets/toolchain, never produce a fake ROM.
10. Emit `build/reports/memory.json`, `rom_map.csv`, `room_coverage.csv`, emulator logs and screenshots. Require measured peak RAM <= 4,194,304 bytes including stacks and buffers.

ROM capacity must be validated against toolchain and cartridge/emulator; 64 MiB is a provisional target, not proven support.

## Architecture
ROM0 engine/code/UI; ROM1 backgrounds/cameras/masks; ROM2 models/animations/collision/audio; ROM3 FMV final. Use offset/size/CRC/compression metadata per asset. Runtime stream only current room and dependencies.

## Current status
Repository Phase A report states no bootable ROM was built or emulated; SDK and emulator missing. No claim of running implementations until acceptance gates pass.
