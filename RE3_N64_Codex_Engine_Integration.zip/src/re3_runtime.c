#include "re3_runtime.h"
int re3_memory_can_reserve(size_t current, size_t requested) {
    return current <= RE3_RDRAM_LIMIT_BYTES && requested <= RE3_RDRAM_LIMIT_BYTES-current;
}
int re3_asset_entry_valid(const re3_asset_entry_t *e, uint32_t rom_size) {
    if (!e || e->bank > RE3_BANK_FMV || e->packed_size == 0 || e->unpacked_size == 0) return 0;
    return e->rom_offset <= rom_size && e->packed_size <= rom_size - e->rom_offset;
}
