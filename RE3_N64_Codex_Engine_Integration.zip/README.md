# RE3 N64 Codex integration patch (source only)
This is **not a compiled N64 ROM**. It supplies a Codex work order and small host-testable C99 primitives for 4 MiB RAM and ROM asset entry bounds. Merge into your existing repository; do not overwrite the existing Makefile or code.

Codex instruction: read `docs/engineering/CODEX_ENGINE_INTEGRATION.md` and implement the gates in order. Report real build and emulator evidence; no fake completion.

Host compile check: `cc -std=c99 -Wall -Wextra -Werror -Iinclude -c src/re3_runtime.c -o /tmp/re3_runtime.o`.
