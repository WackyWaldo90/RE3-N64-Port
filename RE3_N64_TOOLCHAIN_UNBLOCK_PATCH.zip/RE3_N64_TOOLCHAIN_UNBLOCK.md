# RE3 N64 — Toolchain and Emulator Unblock Plan

Date: 2026-10-25. Target: standard Nintendo 64, **4 MiB RDRAM**, no Expansion Pak.

## What the screenshot establishes
- `make test-host` passes for source-only and full local collision corpus.
- `N64_INST` is unset, the compiler distribution is not pinned, and no emulator executable is available in the Codex environment.
- **No cross-compile, boot test, or peak RAM measurement has run.** Local commits do not prove a push to GitHub.
- A repository file cannot override Codex cloud network, package-installation, or sandbox policy.

## Safe order of operations
1. Commit/push the host-test fixes and ensure they appear on the repository's remote branch. Do not overwrite newer collision code.
2. Use an **N64-capable environment**: a self-hosted Linux runner with a preinstalled toolchain, a supported dev container, or a Codex environment with approved network access. A GitHub-hosted Actions runner may install dependencies if upstream servers are accessible. Do not assume Codex cloud allows it.
3. Pin a libdragon commit and a MIPS N64 toolchain distribution/image by immutable digest or revision. Record checksums and provenance in `toolchain.lock` or a similar file. Do not invent pins.
4. Install libdragon using its official installation instructions at https://github.com/DragonMinded/libdragon and ensure its `n64.mk` exists. The required compiler is a **MIPS N64 cross-compiler**, not host GCC. `N64_INST` must point to the actual SDK installation prefix.
5. Install an emulator (for example Ares, https://github.com/ares-emulator/ares) from a trusted release or source; record the exact executable, version, and flags. For automation, verify whether the installed emulator supports a documented headless launch and suitable logging; otherwise use a graphical/virtual-display runner. Do not fabricate a CLI flag.
6. Run `bash scripts/n64-preflight.sh` (included separately). Fix every FAIL before invoking the N64 Makefile. Keep `make test-host` independent of N64 dependencies.
7. Compile a **minimal legal boot smoke test** first, then the project's N64 engine. Use `make -f Makefile.n64` only if that file exists in the current checkout and its targets are verified. Never replace the existing Makefile blindly.
8. Validate `.z64` byte order/header, boot in emulator configured for **4 MiB**, capture stdout/logs and screenshots, and measure peak RAM with instrumentation. ROM existence alone does not prove bootability.
9. Only then connect room loading, backgrounds, collision, models, audio and game logic. Leave FMV conversion last.

## Codex commands (diagnostic; no privileged installation)
```bash
pwd
find . -maxdepth 3 -type f \( -name 'Makefile*' -o -name 'n64.mk' -o -name '*preflight*' \) -print
printf 'N64_INST=%s\n' "${N64_INST:-<unset>}"
command -v mips64-elf-gcc || true
command -v mips64-linux-gnu-gcc || true
command -v ares || true
command -v mupen64plus || true
bash scripts/n64-preflight.sh
make test-host
```

## Example configuration (ONLY after installing libdragon)
```bash
# Replace the path with the real SDK prefix; this is an example, not a verified path.
export N64_INST="$HOME/n64"
# If libdragon's install instructions require additional PATH settings, apply them.
test -f "$N64_INST/n64.mk" && echo 'SDK make include found'
```

## GitHub Actions repair
The existing `.github/workflows/c-cpp.yml` invokes `./configure`, `make check` and `make distcheck`, which are not appropriate unless those targets actually exist. Replace it only after confirming the correct repository paths. The included `re3-host-tests.yml` is a **separate host-test workflow** that locates the source checkout and runs `make test-host` when available; it intentionally does not claim an N64 build.

## RAM verification acceptance
- Target <= 4,194,304 bytes physical RDRAM, including code, stacks, buffers, audio and assets; account for OS/runtime reserved regions.
- Instrument high-water marks of all allocators and DMA/streaming buffers. Measure on emulator/hardware, not only static linker size.
- Include logs and a machine-readable report: toolchain revision, ROM SHA-256, boot outcome, frame/screenshot evidence, peak RAM and failure reason.

## Sources to check when installation is permitted
- libdragon: https://github.com/DragonMinded/libdragon
- libdragon wiki: https://github.com/DragonMinded/libdragon/wiki
- Ares: https://github.com/ares-emulator/ares
- Mupen64Plus: https://github.com/mupen64plus/mupen64plus-core
- GitHub Actions: https://docs.github.com/en/actions

## Important limitation
This package diagnoses the blocker and provides a reproducible preflight. It **does not install** the SDK or emulator, change cloud network permissions, create a bootable ROM, or certify 4 MiB RAM use.
