#!/usr/bin/env bash
set -u
fail=0
check() { if "$@"; then printf 'PASS: %s\n' "$*"; else printf 'FAIL: %s\n' "$*"; fail=1; fi; }
check command -v make
check command -v python3
if [[ -z "${N64_INST:-}" ]]; then
  echo 'FAIL: N64_INST is unset'; fail=1
elif [[ ! -d "$N64_INST" ]]; then
  echo "FAIL: N64_INST directory does not exist: $N64_INST"; fail=1
else
  echo "PASS: N64_INST directory: $N64_INST"
  if [[ -f "$N64_INST/n64.mk" ]]; then echo 'PASS: n64.mk'; else echo 'FAIL: n64.mk not found at N64_INST/n64.mk (inspect SDK layout)'; fail=1; fi
fi
if command -v mips64-elf-gcc >/dev/null 2>&1; then
  mips64-elf-gcc --version | head -n 1
elif command -v mips64-linux-gnu-gcc >/dev/null 2>&1; then
  mips64-linux-gnu-gcc --version | head -n 1
  echo 'WARN: verify ABI and compatibility; generic Linux MIPS GCC is not automatically an N64 libdragon toolchain'
else
  echo 'FAIL: no known MIPS cross-compiler on PATH'; fail=1
fi
if command -v ares >/dev/null 2>&1; then echo 'PASS: ares executable';
elif command -v mupen64plus >/dev/null 2>&1; then echo 'PASS: mupen64plus executable';
else echo 'FAIL: no ares or mupen64plus executable on PATH'; fail=1; fi
if [[ "$fail" -ne 0 ]]; then echo 'N64 preflight BLOCKED'; exit 1; fi
echo 'N64 preflight passed basic presence checks; SDK/ROM/emulator compatibility still requires real tests'
